<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\LoginRequest;
use App\Models\User;
use App\Models\doctor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthenticationController extends Controller
{
    public function action()
    {

        $show = User::latest()->get();
        return response([
            'show' => $show
        ], 200);
    }
    public function register(RegisterRequest $request){ 
        $request->validated();

        $userData = [
            'name' => $request->name,
            'CNI' => $request->CNI,
            'phone_number' => $request->phone_number,
            'Sex' => $request->Sex,
            'date_of_birth' => $request->date_of_birth,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ];

        $user = User::create($userData);
        $token = $user->createToken('patientapp')->plainTextToken;

        return response([
            'user' => $user,
            'token' => $token
        ], 201);
    }
    public function login(LoginRequest $request)
    {
        $request->validated();

        $user = User::whereEmail($request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            return response([
                'message' => 'Invalid credentials'
            ], 422);
        }

        $token = $user->createToken('patientapp')->plainTextToken;

        return response([
            'user' => $user,
            'token' => $token
        ], 200);
    }
    public function patient(){
        $patients = User::all();
        return view ('list-patient')->with('patients', $patients);
      }
    public function deletepatient($id){
        User::where('id','=',$id)->delete();
        return redirect()->back()->with('succes','Patient deleted successfuly');
    }
    public function Editpatient($id){
        $patients=User::where('id','=',$id)->first();
        return view('edit-patient',compact('patients'));
    }
    
    public function updatepatient(Request $request){
        $requestData = $request->all();
        User::where('id','=',$request->id)->update([
            'name'=>$request->name,
            'CNI'=>$request->CNI,
            'phone_number'=>$request->phone_number,
            'Sex'=>$request->Sex,
            'date_of_birth'=>$request->date_of_birth,
            'email'=>$request->email,
        ]);
        return redirect('list-patient')->with('flash_message', 'Member Added!');  
    }
    public function countUsers()
    {
        $userCount = User::count();
        $doctorCount = doctor::count();
        return view('dashboard', compact('userCount','doctorCount'));
    }
}
