<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;
use Session;

class adminController extends Controller
{
    public function login(){
        return view('login');
    }
     public function register(){
        return view('register');
    }
    public function registerUser(Request $request){
        $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:admins',
            'password'=>'required',
            
        ]);
        $admin=new Admin();
        $admin->name=$request->name;
        $admin->email=$request->email;
        $admin->password=Hash::make($request->password);
        
        $res=$admin->save();
        if($res){
            return back()->with('success','you have registered successfuly');
        }else{
            return back()->with('fail','something wrong');
        }
    }
    public function loginUser(Request $request){
        $request->validate([
            'email'=>'required|email',
            'password'=>'required',
            
        ]);
        $admin=Admin::where('email','=',$request->email)->first();
        if($admin){
           if(Hash::check($request->password,$admin->password)){
            $request->session()->put('loginId',$admin->id);
            return redirect('dashboard');
           }else{
            return back()->with('fail','Password not matches');
           }
        }else{
            return back()->with('fail','This email is not registered');
        }
    }
    // public function dashboard(){
    //     return view('dashboard');
    // }
    public function dashboard()
        {
          $data = array();

          if(Session :: has('loginId')){
            $data = Admin::Where('Id','=',Session :: get('loginId') ,)->first();
          }
         return view('dashboard',compact('data'));
    }
    public function logout(){
        if(Session :: has('loginId')){
            Session::pull('loginId');
           return redirect('login');
        }
    }
}
