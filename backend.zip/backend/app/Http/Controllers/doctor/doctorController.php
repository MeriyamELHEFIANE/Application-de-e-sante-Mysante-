<?php

namespace App\Http\Controllers\doctor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\SignupRequest;
use App\Http\Requests\SigninRequest;
use App\Models\doctor;
use App\Models\visit;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class doctorController extends Controller
{
    public function index()
    {

        $feeds = doctor::latest()->get();
        return response([
            'feeds' => $feeds
        ], 200);
    }
    public function signup(SignupRequest $request){
        // $request->validated();
    
        $medData = [
            'name' => $request->name,
            'CNI' => $request->CNI,
            'phone_number' => $request->phone_number,
            'specialite' => $request->specialite,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ];

        $med = doctor::create($medData);
        $token = $med->createToken('patientapp')->plainTextToken;

        return response([
            'med' => $med,
            'token' => $token
        ], 201);
    }
    public function signin(SigninRequest $request)
    {
        $request->validated();

        $med = doctor::whereEmail($request->email)->first();
        if (!$med || !Hash::check($request->password, $med->password)) {
            return response([
                'message' => 'Invalid credentials'
            ], 422);
        }

        $token = $med->createToken('patientapp')->plainTextToken;

        return response([
            'med' => $med,
            'token' => $token
        ], 200);
    }
    
    public function visite(Request $request, $doctor_id)
    {

        $request->validate([
            'date' => 'required',
            'time' => 'required',
            'probleme' => 'required'
        ]);
        $visit = visit::create([
            'user_id' => auth()->id(),
            'doctor_id' => $doctor_id,
            'date' => $request->date,
            'time' => $request->time,
            'probleme' => $request->probleme
        ]);

        return response([
            'message' => 'success'
        ], 201);
    }

    public function getVisits()
{
    $doctorId = auth()->id();

    // Fetch visits associated with the authenticated doctor
    $visits = Visit::with('doctor')->with('user')->where('doctor_id', $doctorId)->latest()->get();

    return response([
        'visits' => $visits
    ], 200);
 }
  public function doctor(){
    $doctors = doctor::all();
    return view ('doctor-list')->with('doctors', $doctors);
  }
  public function deletedoctor($id){
    doctor::where('id','=',$id)->delete();
    return redirect()->back()->with('succes','Patient deleted successfuly');
   }
   public function Editdoctor($id){
    $doctors=doctor::where('id','=',$id)->first();
    return view('edit-doctor',compact('doctors'));
}  

public function updatedoctor(Request $request){
    $requestData = $request->all();
    doctor::where('id','=',$request->id)->update([
        'name'=>$request->name,
        'CNI'=>$request->CNI,
        'phone_number'=>$request->phone_number,
        'specialite'=>$request->specialite,
        'email'=>$request->email,
    ]);
    return redirect('doctor-list')->with('flash_message', 'Member Added!');  
}
public function visit(){
    $doctors = doctor::with('visit')->get();
    // $urgence = Urgence::with('categories')->get();
    $visits = visit::with('doctor')->with('user')->get();
    // $urgences = Urgence::with('user')->get();
    $user = User::with('visit')->get();
    return view('visit',compact('user','visits','doctors'));
}

public function Editvisit($id){
    $visits=visit::where('id','=',$id)->first();
    return view('edit-visit',compact('visits'));
}
public function deletevisit($id){
    visit::where('id','=',$id)->delete();
    return redirect()->back()->with('succes','Patient deleted successfuly');
   }

   public function updatevisit(Request $request){
    $requestData = $request->all();
    visit::where('id','=',$request->id)->update([
        'date'=>$request->date,
        'time'=>$request->time,
        'probleme'=>$request->probleme,
    ]);
    return redirect('visit')->with('flash_message', 'Member Added!');  
   }
    // public function countDoctors()
    // {
    //     $doctorCount = doctor::count();

    //     return view('/dashboard', compact('doctorCount'));
    // }

    // public function getVisits()
    // {
    //     $visits = visit::with('doctor')->with('user')->latest()->get();

    //     return response([
    //         'visits' => $visits
    //     ], 200);
    // }
    
}
