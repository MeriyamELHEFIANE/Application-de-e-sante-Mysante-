<?php

namespace App\Http\Controllers\urgence;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\UrgenceRequest;
use App\Models\Category;
use App\Models\Urgence;
use App\Models\User;
use Illuminate\Support\Facades\DB;
class urgenceController extends Controller
{
    public function urgence()
    {

        $urgences = Urgence::with('user')->get();
        
        return response([
            'urgences' => $urgences
        ], 200);
    }
    public function emergency(UrgenceRequest $request)
    {
        $request->validated();
        
        auth()->user()->urgences()->create([
            'type_of_emergency' => $request->type_of_emergency
        ]);
        return response([
            'message' => 'success',
        ], 201);
    }
    public function categorie(Request $request)
    {

        $request->validate([
            'category' => 'required'
        ]);
        $category = Urgence::latest('id')->first();
        $categoryId = $category->id;
        // $urgence_id = Urgence::with('user')->latest('id')->first('id');
        $typeurgences = Category::create([
            // 'user_id' => auth()->id(),
            'urgence_id' => $categoryId,
            'category' => $request->category
        ]);

        return response([
            'message' => 'success'
        ], 201);
    }
    public function getCategory()
    {
      $category = Urgence::latest('id')->first();
      $categoryId = $category->id;

      return response([
        $categoryId
      ], 200);
    }
    public function urgences(){
        $urgences = Urgence::with('user')->get();
        // $urgences = Urgence::with('user')->get();
        $user = User::with('urgences')->get();
        return view('urgence',compact('user','urgences'));
    }
    public function deleteurgence($id) {
        DB::transaction(function () use ($id) {
            // Delete data from the first table
    
            // Delete data from the second table
            DB::table('urgences')->where('user_id', $id)->delete();
    
            // Delete data from the third table
            DB::table('users')->where('id', $id)->delete();
    
    
            // Commit the transaction
        });
    
        return redirect()->back()->with('success', 'Data deleted successfully');
    }
    public function Editurgence($id){
        $urgences=Urgence::where('id','=',$id)->first();
        return view('edit-urgence',compact('urgences'));
    }
    
    public function updateurgence(Request $request){
        $requestData = $request->all();
        Urgence::where('id','=',$request->id)->update([
            'type_of_emergency'=>$request->type_of_emergency,
        ]);
        return redirect('urgence')->with('flash_message', 'Member Added!');  
    }
    public function liste(){
        $categories = Category::with('urgence')->get();
        // $urgence = Urgence::with('categories')->get();
        $urgences = Urgence::with('categories')->with('user')->get();
        // $urgences = Urgence::with('user')->get();
        $user = User::with('urgences')->get();
        return view('patient-list',compact('user','urgences','categories'));
    }
    public function deleteUser($id) {
        DB::transaction(function () use ($id) {
            // Delete data from the first table
            DB::table('categories')->where('urgence_id', $id)->delete();
    
            // Delete data from the second table
            DB::table('urgences')->where('id', $id)->delete();
    
            // Delete data from the third table
    
    
            // Commit the transaction
        });
    
        return redirect()->back()->with('success', 'Data deleted successfully');
    }
    public function Edituser($id){
        $categories=Category::where('id','=',$id)->first();
        return view('edit-user',compact('categories'));
    }
    
    public function updateuser(Request $request){
        $requestData = $request->all();
        Category::where('id','=',$request->id)->update([
            'category'=>$request->category,
        ]);
        return redirect('patient-list')->with('flash_message', 'Member Added!');  
    }
}
