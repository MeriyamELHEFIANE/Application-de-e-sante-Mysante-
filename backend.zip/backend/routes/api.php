<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticationController;
use App\Http\Controllers\Urgence\urgenceController;
use App\Http\Controllers\doctor\doctorController;
use App\Http\Controllers\specialite\specialiteController;
use App\Http\Controllers\visit\visitController;
// use App\Http\Controllers\TypeUrgence\TypeUrgenceController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::get('/feeds', [doctorController::class, 'index'])->middleware('auth:sanctum');
Route::get('/urgences', [urgenceController::class, 'urgence'])->middleware('auth:sanctum');
Route::get('/show', [AuthenticationController::class, 'action'])->middleware('auth:sanctum');
Route::post('/urgence/emergency', [urgenceController::class, 'emergency'])->middleware('auth:sanctum');
// Route::post('/visit/visite', [visitController::class, 'visite'])->middleware('auth:sanctum');
Route::post('/visit/visite/{doctor_id}', [doctorController::class, 'visite'])->middleware('auth:sanctum');
Route::get('visits', [doctorController::class, 'getVisits'])->middleware('auth:sanctum');
Route::post('/specialite/spetialite', [SpecialiteController::class, 'spetialite'])->middleware('auth:sanctum');
// Route::post('/TypeUrgence/sousUrgence', [TypeUrgenceController::class, 'sousUrgence'])->middleware('auth:sanctum');
// Route::post('specialite', [SpecialiteController::class, 'specialite']);
// Route::post('/feed/like/{feed_id}', [FeedController::class, 'likePost'])->middleware('auth:sanctum');
Route::post('/urgence/categorie', [urgenceController::class, 'categorie'])->middleware('auth:sanctum');
Route::get('/urgence/categories', [urgenceController::class, 'getCategory'])->middleware('auth:sanctum');
Route::get('/test', function () {
    return response([
        'message' => 'Api is working'
    ], 200);
});
Route::post('register',[AuthenticationController::class,'register']);
Route::post('login', [AuthenticationController::class, 'login']);
Route::post('signup',[doctorController::class,'signup']);
Route::post('signin',[doctorController::class,'signin']);