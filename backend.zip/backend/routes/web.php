<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\adminController;
use App\Http\Controllers\urgence\urgenceController;
use App\Http\Controllers\doctor\doctorController;
use App\Http\Controllers\Auth\AuthenticationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('login',[adminController::class,'login'])->middleware('alreadyLoggedIn');
Route::get('register',[adminController::class,'register']);
Route::post('/register-user',[adminController::class,'registerUser'])->name('register-user');
Route::post('/login-user',[adminController::class,'loginUser'])->name('login-user');
Route::get('dashboard',[adminController::class,'dashboard'])->middleware('isLoggedIn');
Route::get('logout',[adminController::class,'logout']);
// Route::get('index', function () {
//     return view('index');
// });
Route::get('patient-list',[urgenceController::class,'liste']);
Route::get('delete-user/{id}',[urgenceController::class,'deleteUser']);
Route::get('delete-user/{id}/{id1}',[urgenceController::class,'deleteUser']);
Route::get('edit-user/{id}',[urgenceController::class,'Edituser']);
Route::post('update-user',[urgenceController::class,'updateuser']);

Route::get('doctor-list',[doctorController::class,'doctor']);
Route::get('delete-doctor/{id}',[doctorController::class,'deletedoctor']);
Route::get('edit-doctor/{id}',[doctorController::class,'Editdoctor']);
Route::post('update-doctor',[doctorController::class,'updatedoctor']);

Route::get('list-patient',[AuthenticationController::class,'patient']);
Route::get('delete-patient/{id}',[AuthenticationController::class,'deletepatient']);
Route::get('edit-patient/{id}',[AuthenticationController::class,'Editpatient']);
Route::post('update-patient',[AuthenticationController::class,'updatepatient']);

Route::get('urgence',[urgenceController::class,'urgences']);
Route::get('delete-urgence/{id}',[urgenceController::class,'deleteurgence']);
Route::get('delete-urgence/{id}',[urgenceController::class,'deleteurgence']);
Route::get('edit-urgence/{id}',[urgenceController::class,'Editurgence']);
Route::post('update-urgence',[urgenceController::class,'updateurgence']);

Route::get('visit',[doctorController::class,'visit']);
Route::get('delete-user/{id}',[urgenceController::class,'deleteUser']);
Route::get('delete-user/{id}',[urgenceController::class,'deleteUser']);
Route::get('edit-visit/{id}',[doctorController::class,'Editvisit']);
Route::get('delete-visit/{id}',[doctorController::class,'deletevisit']);
Route::post('update-visit',[doctorController::class,'updatevisit']);
Route::get('/dashboard', [AuthenticationController::class, 'countUsers']);
// Route::get('/dashboard', [doctorController::class, 'countDoctors']);