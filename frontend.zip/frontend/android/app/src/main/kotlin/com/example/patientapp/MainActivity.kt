package com.example.patientapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
