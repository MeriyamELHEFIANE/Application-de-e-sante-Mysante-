import 'dart:convert';

import 'package:patientapp/constants/constants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:patientapp/screens/welcome_screen.dart';
import 'package:patientapp/widgets/navbar_roots.dart';
// import 'package:patientapp/screens/welcome_screen.dart';

class AuthenticationController extends GetxController {
  final isLoading = false.obs;
  final token = ''.obs;

  final box = GetStorage();

  Future register({
    required String? name,
    required String? CNI,
    required String? phone_number,
    required String? Sex,
    required String? date_of_birth,
    required String? email,
    required String? password,
  }) async {
    try {
      isLoading.value = true;
      var data = {
        'name': name,
        'CNI': CNI,
        'phone_number': phone_number,
        'Sex': Sex,
        'date_of_birth': date_of_birth,
        'email': email,
        'password': password,
      };

      var response = await http.post(
        Uri.parse('${url}register'),
        headers: {
          'Accept': 'application/json',
        },
        body: data,
      );

      if (response.statusCode == 201) {
        isLoading.value = false;
        debugPrint(json.decode(response.body));
        token.value = json.decode(response.body)['token'];
        box.write('token', token.value);
        Get.offAll(() => NavBarRoots());
      } else {
        isLoading.value = false;
        Get.snackbar(
          'Error',
          json.decode(response.body)['message'],
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        debugPrint(json.decode(response.body));
        debugPrint(json.decode(response.body));
      }
    } catch (e) {
      isLoading.value = false;

      debugPrint(e.toString());
    }
  }

  Future login({
    required String email,
    required String password,
  }) async {
    try {
      isLoading.value = true;
      var data = {
        'email': email,
        'password': password,
      };

      var response = await http.post(
        Uri.parse('${url}login'),
        headers: {
          'Accept': 'application/json',
        },
        body: data,
      );

      if (response.statusCode == 200) {
        isLoading.value = false;
        token.value = json.decode(response.body)['token'];
        box.write('token', token.value);
        Get.offAll(() => NavBarRoots());
      } else {
        isLoading.value = false;
        Get.snackbar(
          'Error',
          json.decode(response.body)['message'],
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        debugPrint(json.decode(response.body));
      }
    } catch (e) {
      isLoading.value = false;

      debugPrint(e.toString());
    }
  }

  Future logout() async {
    var response = await http.post(
      Uri.parse('${url}logout'),
      headers: {
        'Accept': 'application/json',
      },
    );
    isLoading.value = false;
    Get.offAll(() => WelcomeScreen());
  }
}
