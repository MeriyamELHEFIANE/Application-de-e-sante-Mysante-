import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

import '../constants/constants.dart';
import '../models/category_model.dart';
import '../models/med_model.dart';
import '../models/visit_model.dart';

class PostController extends GetxController {
  Rx<List<MedModel>> med = Rx<List<MedModel>>([]);
  Rx<List<VisitModel>> visits = Rx<List<VisitModel>>([]);
  final isLoading = false.obs;
  final box = GetStorage();

  @override
  void onInit() {
    getAllPosts();
    // getVisits();
    super.onInit();
  }

  Future getAllPosts() async {
    try {
      med.value.clear();
      isLoading.value = true;
      var response = await http.get(Uri.parse('${url}feeds'), headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${box.read('token')}',
      });
      if (response.statusCode == 200) {
        isLoading.value = false;
        final content = json.decode(response.body)['feeds'];
        for (var item in content) {
          med.value.add(MedModel.fromJson(item));
        }
      } else {
        isLoading.value = false;
        print(json.decode(response.body));
      }
    } catch (e) {
      isLoading.value = false;
      print(e.toString());
    }
  }

  // Future getVisits() async {
  //   try {
  //     visits.value.clear();
  //     isLoading.value = true;
  //     var response = await http.get(Uri.parse('${url}visits'), headers: {
  //       'Accept': 'application/json',
  //       'Authorization': 'Bearer ${box.read('token')}',
  //     });
  //     if (response.statusCode == 200) {
  //       isLoading.value = false;
  //       final content = json.decode(response.body)['visits'];
  //       for (var item in content) {
  //         visits.value.add(VisitModel.fromJson(item));
  //       }
  //     } else {
  //       isLoading.value = false;
  //       print(json.decode(response.body));
  //     }
  //   } catch (e) {
  //     isLoading.value = false;
  //     print(e.toString());
  //   }
  // }

  // Future createPost({
  //   required String specialite,
  // }) async {
  //   try {
  //     var data = {
  //       'specialite': specialite,
  //     };

  //     var response = await http.post(
  //       Uri.parse('${url}specialite/spetialite'),
  //       headers: {
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer ${box.read('token')}',
  //       },
  //       body: data,
  //     );

  //     if (response.statusCode == 201) {
  //       print(json.decode(response.body));
  //     } else {
  //       Get.snackbar(
  //         'Error',
  //         json.decode(response.body)['message'],
  //         snackPosition: SnackPosition.TOP,
  //         backgroundColor: Colors.red,
  //         colorText: Colors.white,
  //       );
  //     }
  //   } catch (e) {
  //     print(e.toString());
  //   }
  // }

  // Future getVisits() async {
  //   try {
  //     visits.value.clear();
  //     isLoading.value = true;

  //     var response = await http.get(
  //       Uri.parse('${url}visits'),
  //       headers: {
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer ${box.read('token')}',
  //       },
  //     );

  //     if (response.statusCode == 200) {
  //       isLoading.value = false;
  //       final content = json.decode(response.body)['visits'];
  //       for (var item in content) {
  //         visits.value.add(VisitModel.fromJson(item));
  //       }
  //     } else {
  //       isLoading.value = false;
  //       print(json.decode(response.body));
  //     }
  //   } catch (e) {
  //     print(e.toString());
  //   }
  // }

  Future createvisit(id, String? date, String? time, String? probleme) async {
    try {
      isLoading.value = true;
      var data = {
        'date': date,
        'time': time,
        'probleme': probleme,
      };

      var request = await http.post(
        Uri.parse('${url}visit/visite/$id'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${box.read('token')}',
        },
        body: data,
      );

      if (request.statusCode == 201) {
        isLoading.value = false;
        print(json.decode(request.body));
      } else {
        isLoading.value = false;
        print(json.decode(request.body));
      }
    } catch (e) {
      print(e.toString());
    }
  }

  // //category
  // Future getCategory(id) async {
  //   try {
  //     categories.value.clear();
  //     isLoading.value = true;

  //     var response = await http.get(
  //       Uri.parse('${url}feed/categories/$id'),
  //       headers: {
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer ${box.read('token')}',
  //       },
  //     );

  //     if (response.statusCode == 200) {
  //       isLoading.value = false;
  //       final content = json.decode(response.body)['categories'];
  //       for (var item in content) {
  //         categories.value.add(CategoryModel.fromJson(item));
  //       }
  //     } else {
  //       isLoading.value = false;
  //       print(json.decode(response.body));
  //     }
  //   } catch (e) {
  //     print(e.toString());
  //   }
  // }

  // Future createCategory(id, reponse) async {
  //   try {
  //     isLoading.value = true;
  //     var data = {
  //       'reponse': reponse,
  //     };

  //     var request = await http.post(
  //       Uri.parse('${url}feed/category/$id'),
  //       headers: {
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer ${box.read('token')}',
  //       },
  //       body: data,
  //     );

  //     if (request.statusCode == 201) {
  //       isLoading.value = false;
  //       print(json.decode(request.body));
  //     } else {
  //       isLoading.value = false;
  //       print(json.decode(request.body));
  //     }
  //   } catch (e) {
  //     print(e.toString());
  //   }
  // }

  // Future likeAndDislike(id) async {
  //   try {
  //     isLoading.value = true;
  //     var request = await http.post(
  //       Uri.parse('${url}feed/like/$id'),
  //       headers: {
  //         'Accept': 'application/json',
  //         'Authorization': 'Bearer ${box.read('token')}',
  //       },
  //     );
  //     if (request.statusCode == 200 ||
  //         json.decode(request.body)['message'] == 'liked') {
  //       isLoading.value = false;
  //       print(json.decode(request.body));
  //     } else if (request.statusCode == 200 ||
  //         json.decode(request.body)['message'] == 'Unliked') {
  //       isLoading.value = false;
  //       print(json.decode(request.body));
  //     } else {
  //       isLoading.value = false;
  //       print(json.decode(request.body));
  //     }
  //   } catch (e) {
  //     print(e.toString());
  //   }
  // }
}
