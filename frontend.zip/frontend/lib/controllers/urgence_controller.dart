import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:patientapp/constants/constants.dart';
import 'package:patientapp/models/urgence_model.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;

import '../models/category_model.dart';

class UrgenceController extends GetxController {
  Rx<List<UrgenceModel>> posts = Rx<List<UrgenceModel>>([]);
  Rx<List<CategoryModel>> categories = Rx<List<CategoryModel>>([]);
  final isLoading = false.obs;
  final box = GetStorage();

  @override
  void onInit() {
    getAllUrgences();
    super.onInit();
  }

  Future getAllUrgences() async {
    try {
      posts.value.clear();
      isLoading.value = true;
      var response = await http.get(Uri.parse('${url}urgences'), headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer ${box.read('token')}',
      });
      if (response.statusCode == 200) {
        isLoading.value = false;
        final content = json.decode(response.body)['urgences'];
        for (var item in content) {
          posts.value.add(UrgenceModel.fromJson(item));
        }
      } else {
        isLoading.value = false;
        print(json.decode(response.body));
      }
    } catch (e) {
      isLoading.value = false;
      print(e.toString());
    }
  }

  Future createPost({
    required String type_of_emergency,
  }) async {
    try {
      var data = {
        'type_of_emergency': type_of_emergency,
      };

      var response = await http.post(
        Uri.parse('${url}urgence/emergency'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${box.read('token')}',
        },
        body: data,
      );

      if (response.statusCode == 201) {
        print(json.decode(response.body));
      } else {
        Get.snackbar(
          'Error',
          json.decode(response.body)['message'],
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }
    } catch (e) {
      print(e.toString());
    }
  }

  Future getCategory() async {
    try {
      categories.value.clear();
      isLoading.value = true;

      var response = await http.get(
        Uri.parse('${url}urgence/categories'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${box.read('token')}',
        },
      );

      if (response.statusCode == 200) {
        isLoading.value = false;
        final content = json.decode(response.body)['categories'];
        for (var item in content) {
          categories.value.add(CategoryModel.fromJson(item));
        }
      } else {
        isLoading.value = false;
        print(json.decode(response.body));
      }
    } catch (e) {
      print(e.toString());
    }
  }

  Future createCategory(category) async {
    try {
      isLoading.value = true;
      var data = {
        'category': category,
      };

      var request = await http.post(
        Uri.parse('${url}urgence/categorie'),
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ${box.read('token')}',
        },
        body: data,
      );

      if (request.statusCode == 201) {
        isLoading.value = false;
        print(json.decode(request.body));
      } else {
        isLoading.value = false;
        print(json.decode(request.body));
      }
    } catch (e) {
      print(e.toString());
    }
  }
}
