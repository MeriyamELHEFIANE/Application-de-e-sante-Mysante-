import 'dart:convert';

CategoryModel commentModelFromJson(String str) =>
    CategoryModel.fromJson(json.decode(str));

String commentModelToJson(CategoryModel data) => json.encode(data.toJson());

class CategoryModel {
  CategoryModel({
    this.id,
    // this.userId,
    this.urgenceId,
    this.body,
    this.createdAt,
    this.updatedAt,
    this.urgence,
    // this.user,
  });

  int? id;
  int? urgenceId;
  String? body;
  DateTime? createdAt;
  DateTime? updatedAt;
  Urgence? urgence;

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
        id: json["id"],
        urgenceId: json["urgence_id"],
        body: json["body"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        urgence: Urgence.fromJson(json["urgence"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "urgence_id": urgenceId,
        "body": body,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "urgence": urgence!.toJson(),
      };
}

class Urgence {
  Urgence({
    this.id,
    this.userId,
    this.type_of_emergency,
    this.createdAt,
    this.updatedAt,
    this.liked,
  });

  int? id;
  int? userId;
  String? type_of_emergency;
  DateTime? createdAt;
  DateTime? updatedAt;
  bool? liked;

  factory Urgence.fromJson(Map<String, dynamic> json) => Urgence(
        id: json["id"],
        userId: json["user_id"],
        type_of_emergency: json["type_of_emergency"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        liked: json["liked"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "type_of_emergency": type_of_emergency,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "liked": liked,
      };
}

// class User {
//   User({
//     this.id,
//     this.name,
//     this.username,
//     this.email,
//     this.emailVerifiedAt,
//     this.createdAt,
//     this.updatedAt,
//   });

//   int? id;
//   String? name;
//   String? username;
//   String? email;
//   dynamic emailVerifiedAt;
//   DateTime? createdAt;
//   DateTime? updatedAt;

//   factory User.fromJson(Map<String?, dynamic> json) => User(
//         id: json["id"],
//         name: json["name"],
//         username: json["username"],
//         email: json["email"],
//         emailVerifiedAt: json["email_verified_at"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//       );

//   Map<String?, dynamic> toJson() => {
//         "id": id,
//         "name": name,
//         "username": username,
//         "email": email,
//         "email_verified_at": emailVerifiedAt,
//         "created_at": createdAt!.toIso8601String(),
//         "updated_at": updatedAt!.toIso8601String(),
//       };
// }
