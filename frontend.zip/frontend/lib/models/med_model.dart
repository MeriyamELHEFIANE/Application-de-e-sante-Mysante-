import 'dart:convert';

MedModel medModelFromJson(String str) => MedModel.fromJson(json.decode(str));

String urgenceModelToJson(MedModel data) => json.encode(data.toJson());

// class MedModel {
//   MedModel({
//     this.id,
//     this.userId,
//     this.specialite,
//     this.createdAt,
//     this.updatedAt,
//     // this.liked,
//     this.medecin,
//   });

//   int? id;
//   int? userId;
//   String? specialite;
//   DateTime? createdAt;
//   DateTime? updatedAt;
//   // bool? liked;
//   Medecin? medecin;

//   factory MedModel.fromJson(Map<String, dynamic> json) => MedModel(
//         id: json["id"],
//         userId: json["medecin_id"],
//         specialite: json["specialite"],
//         createdAt: DateTime.parse(json["created_at"]),
//         updatedAt: DateTime.parse(json["updated_at"]),
//         // liked: json["liked"],
//         medecin: Medecin.fromJson(json["medecin"]),
//       );

//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "medecin_id": userId,
//         "specialite": specialite,
//         "created_at": createdAt!.toIso8601String(),
//         "updated_at": updatedAt!.toIso8601String(),
//         "medecin": medecin!.toJson(),
//       };
// }

class MedModel {
  MedModel({
    this.id,
    this.name,
    this.CNI,
    this.phone_number,
    this.specialite,
    this.email,
    this.emailVerifiedAt,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? name;
  String? CNI;
  String? phone_number;
  String? specialite;
  String? email;
  dynamic? emailVerifiedAt;
  DateTime? createdAt;
  DateTime? updatedAt;

  factory MedModel.fromJson(Map<String, dynamic> json) => MedModel(
        id: json["id"],
        name: json["name"],
        CNI: json["CNI"],
        phone_number: json["phone_number"],
        specialite: json["specialite"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "CNI": CNI,
        "phone_number": phone_number,
        "specialite": specialite,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
      };
}
