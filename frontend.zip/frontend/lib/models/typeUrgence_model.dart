import 'dart:convert';

typeUrgenceModel typeurgenceModelFromJson(String str) =>
    typeUrgenceModel.fromJson(json.decode(str));

String typeurgenceModelToJson(typeUrgenceModel data) =>
    json.encode(data.toJson());

class typeUrgenceModel {
  typeUrgenceModel({
    this.id,
    this.urgenceId,
    this.sous_urgence,
    this.createdAt,
    this.updatedAt,
    this.Urgence,
  });

  int? id;
  int? urgenceId;
  String? sous_urgence;
  DateTime? createdAt;
  DateTime? updatedAt;
  urgence? Urgence;

  factory typeUrgenceModel.fromJson(Map<String, dynamic> json) =>
      typeUrgenceModel(
        id: json["id"],
        urgenceId: json["urgence_id"],
        sous_urgence: json["sous_urgence"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        Urgence: urgence.fromJson(json["urgence"]),
      );

  get type_of_emergency => null;

  Map<String, dynamic> toJson() => {
        "id": id,
        "urgence_id": urgenceId,
        "sous_urgence": sous_urgence,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "urgence": Urgence!.toJson(),
      };
}

class urgence {
  urgence({
    this.id,
    this.userId,
    this.type_of_emergency,
    this.createdAt,
    this.updatedAt,
    this.liked,
  });

  int? id;
  int? userId;
  String? type_of_emergency;
  DateTime? createdAt;
  DateTime? updatedAt;
  bool? liked;

  factory urgence.fromJson(Map<String, dynamic> json) => urgence(
        id: json["id"],
        userId: json["user_id"],
        type_of_emergency: json["type_of_emergency"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "type_of_emergency": type_of_emergency,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
      };
}
