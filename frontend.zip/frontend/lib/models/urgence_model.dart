import 'dart:convert';

UrgenceModel urgenceModelFromJson(String str) =>
    UrgenceModel.fromJson(json.decode(str));

String urgenceModelToJson(UrgenceModel data) => json.encode(data.toJson());

class UrgenceModel {
  UrgenceModel({
    this.id,
    this.userId,
    this.type_of_emergency,
    this.createdAt,
    this.updatedAt,
    // this.liked,
    this.user,
  });

  int? id;
  int? userId;
  String? type_of_emergency;
  DateTime? createdAt;
  DateTime? updatedAt;
  // bool? liked;
  User? user;

  factory UrgenceModel.fromJson(Map<String, dynamic> json) => UrgenceModel(
        id: json["id"],
        userId: json["user_id"],
        type_of_emergency: json["type_of_emergency"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        // liked: json["liked"],
        user: User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "type_of_emergency": type_of_emergency,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        // "liked": liked,
        "user": user!.toJson(),
      };
}

class User {
  User({
    this.id,
    this.name,
    this.CNI,
    this.phone_number,
    this.Sex,
    this.date_of_birth,
    this.email,
    this.emailVerifiedAt,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? name;
  String? CNI;
  String? phone_number;
  String? Sex;
  String? date_of_birth;
  String? email;
  dynamic? emailVerifiedAt;
  DateTime? createdAt;
  DateTime? updatedAt;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        name: json["name"],
        CNI: json["CNI"],
        phone_number: json["phone_number"],
        Sex: json["Sex"],
        date_of_birth: json["date_of_birth"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "CNI": CNI,
        "phone_number": phone_number,
        "Sex": Sex,
        "date_of_birth": date_of_birth,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
      };
}
