import 'dart:convert';

VisitModel visitModelFromJson(String str) =>
    VisitModel.fromJson(json.decode(str));

String visitModelToJson(VisitModel data) => json.encode(data.toJson());

class VisitModel {
  VisitModel({
    this.id,
    this.userId,
    this.doctorId,
    this.date,
    this.time,
    this.probleme,
    this.createdAt,
    this.updatedAt,
    this.doctor,
    this.user,
  });

  int? id;
  int? userId;
  int? doctorId;
  String? date;
  String? time;
  String? probleme;
  DateTime? createdAt;
  DateTime? updatedAt;
  Doctor? doctor;
  User? user;

  factory VisitModel.fromJson(Map<String, dynamic> json) => VisitModel(
        id: json["id"],
        userId: json["user_id"],
        doctorId: json["doctor_id"],
        date: json["date"],
        time: json["time"],
        probleme: json["probleme"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        doctor: Doctor.fromJson(json["doctor"]),
        user: User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "doctor_id": doctorId,
        "date": date,
        "time": time,
        "probleme": probleme,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "doctor": doctor!.toJson(),
        "user": user!.toJson(),
      };
}

class Doctor {
  Doctor({
    this.id,
    this.name,
    this.CNI,
    this.phone_number,
    this.email,
    this.emailVerifiedAt,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? name;
  String? CNI;
  String? phone_number;
  String? email;
  dynamic emailVerifiedAt;
  DateTime? createdAt;
  DateTime? updatedAt;

  factory Doctor.fromJson(Map<String, dynamic> json) => Doctor(
        id: json["id"],
        name: json["name"],
        CNI: json["CNI"],
        phone_number: json["phone_number"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "CNI": CNI,
        "phone_number": phone_number,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
      };
}

class User {
  User({
    this.id,
    this.name,
    this.CNI,
    this.phone_number,
    this.Sex,
    this.date_of_birth,
    this.email,
    this.emailVerifiedAt,
    this.createdAt,
    this.updatedAt,
  });

  int? id;
  String? name;
  String? CNI;
  String? phone_number;
  String? Sex;
  String? date_of_birth;
  String? email;
  dynamic emailVerifiedAt;
  DateTime? createdAt;
  DateTime? updatedAt;

  factory User.fromJson(Map<String?, dynamic> json) => User(
        id: json["id"],
        name: json["name"],
        CNI: json["CNI"],
        phone_number: json["phone_number"],
        Sex: json["Sex"],
        date_of_birth: json["date_of_birth"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String?, dynamic> toJson() => {
        "id": id,
        "name": name,
        "CNI": CNI,
        "phone_number": phone_number,
        "Sex": Sex,
        "date_of_birth": date_of_birth,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
      };
}
