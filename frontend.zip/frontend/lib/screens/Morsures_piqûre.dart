// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:patientapp/screens/settings_screen.dart';
// import 'package:patientapp/screens/traumatic_card.dart';
// import 'package:patientapp/screens/util/category_card.dart';
// import 'package:patientapp/screens/util/doctor_card.dart';
// import 'package:lottie/lottie.dart';

// import 'home.dart';

// class Morsure extends StatefulWidget {
//   @override
//   _MorsureState createState() => _MorsureState();
// }

// class _MorsureState extends State<Morsure> {
//   int _selectedIndex = 0;
//   final _screens = [
//     //home screen
//     MyHomePage(),
//     //message Screen
//     Container(),
//     //Schedule Screen
//     Container(),
//     //Settings screen
//     SettingsScreen(),
//   ];
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey[300],
//       appBar: AppBar(
//         backgroundColor: Colors.green[300],
//         elevation: 0,
//         // leading: Icon(Icons.arrow_back_ios_new),
//         title: Text("Home"),
//       ),
//       body: SafeArea(
//         child: Column(
//           children: [
//             //appBar
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 25.0),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   //name
//                   // Column(
//                   //   crossAxisAlignment: CrossAxisAlignment.start,
//                   //   children: [
//                   //     Text(
//                   //       'Hello,',
//                   //       style: TextStyle(
//                   //         fontWeight: FontWeight.bold,
//                   //         fontSize: 18,
//                   //       ),
//                   //     ),
//                   //     SizedBox(height: 8),
//                   //     Text(
//                   //       'Meriyam Elhefiane,',
//                   //       style: TextStyle(
//                   //         fontSize: 24,
//                   //         fontWeight: FontWeight.bold,
//                   //       ),
//                   //     ),
//                   //   ],
//                   // ),
//                   //profile picture
//                   // Container(
//                   //   padding: EdgeInsets.all(12),
//                   //   decoration: BoxDecoration(
//                   //     color: Colors.deepPurple[100],
//                   //     borderRadius: BorderRadius.circular(12),
//                   //   ),
//                   //   child: Icon(Icons.person),
//                   // ),
//                 ],
//               ),
//             ),
//             SizedBox(height: 25),
//             //card->how do you feel
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 25.0),
//               child: Container(
//                 padding: EdgeInsets.all(20),
//                 decoration: BoxDecoration(
//                   color: Colors.green[200],
//                   borderRadius: BorderRadius.circular(12),
//                 ),
//                 child: Row(
//                   children: [
//                     //animation or cute picture
//                     Container(
//                       height: 200,
//                       width: 200,
//                       child: Lottie.network(
//                         "https://assets5.lottiefiles.com/packages/lf20_HBUbm2mjqt.json",
//                       ),
//                     ),
//                     SizedBox(
//                       height: 20,
//                     ),
//                     //how do you feel + get started button
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             'How do you feel?',
//                             style: TextStyle(
//                               fontWeight: FontWeight.bold,
//                               fontSize: 16,
//                             ),
//                           ),
//                           SizedBox(height: 12),
//                           Text(
//                             'Choose your emergency below right now',
//                             style: TextStyle(
//                               fontSize: 14,
//                             ),
//                           ),
//                           SizedBox(height: 12),
//                           Container(
//                             padding: EdgeInsets.all(12),
//                             decoration: BoxDecoration(
//                               color: Colors.deepPurple[300],
//                               borderRadius: BorderRadius.circular(12),
//                             ),
//                             child: Center(
//                               child: Text(
//                                 '',
//                                 style: TextStyle(color: Colors.white),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//             SizedBox(height: 50),
//             //search bar
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 25.0),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     'Type of emergency list',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 24,
//                     ),
//                   ),
//                   Text(
//                     'see all',
//                     style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 18,
//                       color: Colors.grey[500],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             SizedBox(height: 50),
//             //horizontal listview
//             Container(
//               height: 200,
//               child: ListView(
//                 scrollDirection: Axis.horizontal,
//                 children: [
//                   InkWell(
//                     onTap: () {},
//                     child: Column(
//                       children: [
//                         TraumaticCard(
//                           categoryName: 'Morsure chien/chat',
//                           IconImagePath: 'lib/icons/os-casse.png',
//                         ),
//                       ],
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {},
//                     child: Column(
//                       children: [
//                         TraumaticCard(
//                           categoryName: 'Morsure serpent',
//                           IconImagePath: 'lib/icons/entorse.png',
//                         ),
//                       ],
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {},
//                     child: Column(
//                       children: [
//                         TraumaticCard(
//                           categoryName: 'Piqûre scorpion',
//                           IconImagePath: 'lib/icons/blessure.png',
//                         ),
//                       ],
//                     ),
//                   ),
//                   InkWell(
//                     onTap: () {},
//                     child: Column(
//                       children: [
//                         TraumaticCard(
//                           categoryName: 'Piqûre abeille',
//                           IconImagePath: 'lib/icons/blessure.png',
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             SizedBox(height: 25),
//             //doctor list
//             // Padding(
//             //   padding: const EdgeInsets.symmetric(horizontal: 25.0),
//             //   child: Row(
//             //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             //     children: [
//             //       Text(
//             //         'Doctor list',
//             //         style: TextStyle(
//             //           fontWeight: FontWeight.bold,
//             //           fontSize: 20,
//             //         ),
//             //       ),
//             //       Text(
//             //         'see all',
//             //         style: TextStyle(
//             //           fontWeight: FontWeight.bold,
//             //           fontSize: 16,
//             //           color: Colors.grey[500],
//             //         ),
//             //       ),
//             //     ],
//             //   ),
//             // ),
//             SizedBox(height: 25),
//             // Expanded(
//             //   child: ListView(
//             //     scrollDirection: Axis.horizontal,
//             //     children: [
//             //       DoctorCard(
//             //         doctorImagePath: 'lib/images/doctor1.jpg',
//             //         rating: '4,9',
//             //         doctorName: 'Dr. Ganesh Gupta',
//             //         doctorProfession: 'Therapist',
//             //       ),
//             //       DoctorCard(
//             //         doctorImagePath: 'lib/images/doctor2.jpg',
//             //         rating: '4,4',
//             //         doctorName: 'Dr. Ganesh Gupta',
//             //         doctorProfession: 'Therapist',
//             //       ),
//             //       DoctorCard(
//             //         doctorImagePath: 'lib/images/doctor3.jpg',
//             //         rating: '4,9',
//             //         doctorName: 'Dr. Ganesh Gupta',
//             //         doctorProfession: 'Therapist',
//             //       ),
//             //     ],
//             //   ),
//             // ),
//           ],
//         ),
//       ),
//     );
//   }
// }
