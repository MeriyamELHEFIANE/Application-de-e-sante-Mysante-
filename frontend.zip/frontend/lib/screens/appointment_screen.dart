import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class AppointmentScreen extends StatelessWidget {
  List imgs = [
    "doctor1.jpg",
    "doctor2.jpg",
    "doctor3.jpg",
    "doctor4.jpg",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 101, 214, 157),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Stack(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Icon(
                                Icons.arrow_back_ios_new,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                            InkWell(
                              onTap: () {},
                              child: Icon(
                                Icons.more_vert,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Lottie.network(
                                "https://assets2.lottiefiles.com/private_files/lf30_4FGi6N.json",
                              ),
                              // CircleAvatar(
                              //   radius: 35,
                              //   backgroundImage:
                              //       AssetImage("assets/doctor1.jpg"),
                              // ),
                              SizedBox(height: 15),
                              // Text(
                              //   "Dr. Doctor Name",
                              //   style: TextStyle(
                              //     fontSize: 23,
                              //     fontWeight: FontWeight.w500,
                              //     color: Colors.white,
                              //   ),
                              // ),
                              // SizedBox(height: 5),
                              // Text(
                              //   "Therapist",
                              //   style: TextStyle(
                              //     color: Colors.white,
                              //     fontWeight: FontWeight.bold,
                              //   ),
                              // ),
                              SizedBox(height: 5),
                              // Row(
                              //   mainAxisAlignment: MainAxisAlignment.center,
                              //   children: [
                              //     Container(
                              //       padding: EdgeInsets.all(10),
                              //       decoration: BoxDecoration(
                              //         color: Color.fromARGB(255, 69, 146, 108),
                              //         shape: BoxShape.circle,
                              //       ),
                              //       child: Icon(
                              //         Icons.call,
                              //         color: Colors.white,
                              //         size: 25,
                              //       ),
                              //     ),
                              //     SizedBox(width: 20),
                              //     Container(
                              //       padding: EdgeInsets.all(10),
                              //       decoration: BoxDecoration(
                              //         color: Color.fromARGB(255, 69, 146, 108),
                              //         shape: BoxShape.circle,
                              //       ),
                              //       child: Icon(
                              //         CupertinoIcons.chat_bubble_text_fill,
                              //         color: Colors.white,
                              //         size: 25,
                              //       ),
                              //     ),
                              //   ],
                              // ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              height: MediaQuery.of(context).size.height / 1.5,
              width: double.infinity,
              padding: EdgeInsets.only(
                top: 20,
                left: 15,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    "Bras:",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Placer le bras fracturé contre la poitrine et l’entourer en écharpe avec un tissu noué derrière le cou",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Jambe:",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Placer une attelle rigide provisoire (planchette de bois) de part et d’autre de la jambe fracturée et maintenir le tout avec un tissu noué (ne pas serrer trop fort pour ne pas altérer la circulation sanguine)",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Cuisse:",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Ne pas mobiliser la cuisse, ne pas essayer de redresser, ne pas boire, ne pas manger",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "Fracture ouverte:",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "Ne pas bouger le membre, si l’os est visible, le protéger avec des compresses stériles ou avec un linge propre pour réduire le risque d’infection Ne jamais appuyer sur la fracture, ne jamais essayer de remettre l’os en place",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  // Row(
                  //   children: [
                  //     Text(
                  //       "Reviews",
                  //       style: TextStyle(
                  //         fontSize: 18,
                  //         fontWeight: FontWeight.w500,
                  //       ),
                  //     ),
                  //     SizedBox(width: 10),
                  //     Icon(Icons.star, color: Colors.amber),
                  //     Text(
                  //       "4.9",
                  //       style: TextStyle(
                  //         fontWeight: FontWeight.w500,
                  //         fontSize: 16,
                  //       ),
                  //     ),
                  //     SizedBox(width: 5),
                  //     Text(
                  //       "(124)",
                  //       style: TextStyle(
                  //         fontWeight: FontWeight.w500,
                  //         fontSize: 16,
                  //         color: Color.fromARGB(255, 69, 146, 108),
                  //       ),
                  //     ),
                  //   ],
                  // ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
