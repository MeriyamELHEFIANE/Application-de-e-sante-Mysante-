import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import '../controllers/medecin_controller.dart';
import '../models/med_model.dart';

class DoctorDetails extends StatefulWidget {
  const DoctorDetails({super.key, required this.post});

  final MedModel post;

  @override
  State<DoctorDetails> createState() => _PostDetailsState();
}

class _PostDetailsState extends State<DoctorDetails> {
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _problemeController = TextEditingController();
  final PostController _medController = Get.put(PostController());

  @override
  // void initState() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     _medController.getVisits(widget.post.id);
  //   });
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 101, 214, 157),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: Stack(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Stack(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Icon(
                                Icons.arrow_back_ios_new,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                            InkWell(
                              onTap: () {},
                              child: Icon(
                                Icons.more_vert,
                                color: Colors.white,
                                size: 25,
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              // Lottie.network(
                              //   "https://assets2.lottiefiles.com/private_files/lf30_4FGi6N.json",
                              // ),
                              CircleAvatar(
                                radius: 35,
                                backgroundImage:
                                    AssetImage("assets/doctor_icn.png"),
                              ),
                              SizedBox(height: 15),
                              Text(
                                'Dr.',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 69, 146, 108),
                                ),
                              ),
                              Text(
                                widget.post.name!,
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 69, 146, 108),
                                ),
                              ),
                              SizedBox(height: 5),
                              // Text(
                              //   '',
                              //   style: TextStyle(
                              //     fontSize: 18,
                              //     fontWeight: FontWeight.bold,
                              //     color: Colors.white,
                              //   ),
                              // ),
                              Text(
                                widget.post.specialite!,
                                style: TextStyle(
                                  color: Color.fromARGB(255, 69, 146, 108),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              // Text(
                              //   widget.post.phone_number!,
                              //   style: TextStyle(
                              //     color: Colors.white,
                              //     fontWeight: FontWeight.bold,
                              //   ),
                              // ),
                              // SizedBox(height: 5),
                              // Text(
                              //   widget.post.email!,
                              //   style: TextStyle(
                              //     color: Colors.white,
                              //     fontWeight: FontWeight.bold,
                              //   ),
                              // ),
                              SizedBox(height: 5),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(10),
                                    // decoration: BoxDecoration(
                                    //   color: Color.fromARGB(255, 69, 146, 108),
                                    //   shape: BoxShape.circle,
                                    // ),
                                    child: Icon(
                                      Icons.call,
                                      color: Color.fromARGB(255, 69, 146, 108),
                                      size: 25,
                                    ),
                                  ),
                                  SizedBox(height: 10),
                                  Text(
                                    widget.post.phone_number!,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 69, 146, 108),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 10),
                                  Container(
                                      padding: EdgeInsets.all(10),
                                      // decoration: BoxDecoration(
                                      //   color:
                                      //       Color.fromARGB(255, 69, 146, 108),
                                      //   shape: BoxShape.circle,
                                      // ),
                                      child: Column(
                                        children: [
                                          Icon(
                                            CupertinoIcons
                                                .chat_bubble_text_fill,
                                            color: Color.fromARGB(
                                                255, 69, 146, 108),
                                            size: 25,
                                          ),
                                        ],
                                      )),
                                  SizedBox(height: 10),
                                  Text(
                                    widget.post.email!,
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 69, 146, 108),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              height: MediaQuery.of(context).size.height / 1.5,
              width: double.infinity,
              padding: EdgeInsets.only(
                top: 20,
                left: 15,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    "Veuilllez enter les informations pour prendre le rendez-vous:",
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  // SizedBox(height: 5),
                  // Text(
                  //   widget.post.email!,
                  //   style: TextStyle(
                  //     fontSize: 16,
                  //     color: Colors.black54,
                  //   ),
                  // ),
                  SizedBox(height: 30),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "Date",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.schedule),
                      ),
                      controller: _dateController,
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "Heure",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.schedule),
                      ),
                      controller: _timeController,
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
                    child: TextField(
                      decoration: InputDecoration(
                        labelText: "probleme",
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.sync_problem),
                      ),
                      controller: _problemeController,
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: SizedBox(
                      width: double.infinity,
                      child: Material(
                        color: Color.fromARGB(255, 69, 146, 108),
                        // color: Color.fromARGB(255, 101, 214, 157),
                        borderRadius: BorderRadius.circular(10),
                        child: InkWell(
                          onTap: () async {
                            await _medController.createvisit(
                              widget.post.id,
                              _dateController.text.trim(),
                              _timeController.text.trim(),
                              _problemeController.text.trim(),
                            );
                            _dateController.clear();
                            _timeController.clear();
                            _problemeController.clear();
                          },
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                              vertical: 15,
                              horizontal: 40,
                            ),
                            child: Center(
                              child: Obx(() {
                                return _medController.isLoading.value
                                    ? const Center(
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                        ),
                                      )
                                    : Text(
                                        "Envoyez",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 25,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      );
                              }),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // TextField(
                  //   decoration: InputDecoration(
                  //     labelText: "Phone Number",
                  //     border: OutlineInputBorder(),
                  //     prefixIcon: Icon(Icons.phone),
                  //   ),
                  //   controller: _dateController,
                  // ),
                  // TextField(
                  //   decoration: InputDecoration(
                  //     labelText: "Phone Number",
                  //     border: OutlineInputBorder(),
                  //     prefixIcon: Icon(Icons.phone),
                  //   ),
                  //   controller: _timeController,
                  // ),
                  // TextField(
                  //   decoration: InputDecoration(
                  //     labelText: "Phone Number",
                  //     border: OutlineInputBorder(),
                  //     prefixIcon: Icon(Icons.phone),
                  //   ),
                  //   controller: _problemeController,
                  // ),
                  // ElevatedButton(
                  //   style: ElevatedButton.styleFrom(
                  //     backgroundColor: Colors.black,
                  //     elevation: 0,
                  //     padding: const EdgeInsets.symmetric(
                  //       horizontal: 50,
                  //       vertical: 10,
                  //     ),
                  //   ),
                  //   onPressed: () async {
                  //     await _medController.createvisit(
                  //       widget.post.id,
                  //       _dateController.text.trim(),
                  //       _timeController.text.trim(),
                  //       _problemeController.text.trim(),
                  //     );
                  //     _dateController.clear();
                  //     _timeController.clear();
                  //     _problemeController.clear();
                  //   },
                  //   child: const Text('Comment'),
                  // ),
                ],
              ),
            ),
          ],
        ),
      ),
      // SingleChildScrollView(
      //   child: Padding(
      //     padding: const EdgeInsets.all(8.0),
      //     child: Column(
      //       children: [
      //         const SizedBox(
      //           height: 10,
      //         ),
      //         Text(
      //           widget.post.name!,
      //           style: TextStyle(
      //             fontSize: 18,
      //             fontWeight: FontWeight.w500,
      //             color: Colors.black54,
      //           ),
      //         ),
      //         // Container(
      //         //   width: double.infinity,
      //         //   height: 300,
      //         //   child: Obx(() {
      //         //     return _medController.isLoading.value
      //         //         ? Center(
      //         //             child: CircularProgressIndicator(),
      //         //           )
      //         //         : ListView.builder(
      //         //             itemCount: _medController.visits.value.length,
      //         //             shrinkWrap: true,
      //         //             itemBuilder: (context, index) {
      //         //               return ListTile(
      //         //                 title: Text(
      //         //                   _medController
      //         //                       .visits.value[index].user!.name!,
      //         //                 ),
      //         //                 subtitle: Text(
      //         //                   _medController.visits.value[index].body!,
      //         //                 ),
      //         //               );
      //         //             });
      //         //   }),
      //         // ),
      //         TextField(
      //           decoration: InputDecoration(
      //             labelText: "Phone Number",
      //             border: OutlineInputBorder(),
      //             prefixIcon: Icon(Icons.phone),
      //           ),
      //           controller: _dateController,
      //         ),
      //         TextField(
      //           decoration: InputDecoration(
      //             labelText: "Phone Number",
      //             border: OutlineInputBorder(),
      //             prefixIcon: Icon(Icons.phone),
      //           ),
      //           controller: _timeController,
      //         ),
      //         TextField(
      //           decoration: InputDecoration(
      //             labelText: "Phone Number",
      //             border: OutlineInputBorder(),
      //             prefixIcon: Icon(Icons.phone),
      //           ),
      //           controller: _problemeController,
      //         ),

      //         ElevatedButton(
      //           style: ElevatedButton.styleFrom(
      //             backgroundColor: Colors.black,
      //             elevation: 0,
      //             padding: const EdgeInsets.symmetric(
      //               horizontal: 50,
      //               vertical: 10,
      //             ),
      //           ),
      //           onPressed: () async {
      //             await _medController.createvisit(
      //               widget.post.id,
      //               _dateController.text.trim(),
      //               _timeController.text.trim(),
      //               _problemeController.text.trim(),
      //             );
      //             _dateController.clear();
      //             _timeController.clear();
      //             _problemeController.clear();
      //           },
      //           child: const Text('Comment'),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
    );
  }
}
