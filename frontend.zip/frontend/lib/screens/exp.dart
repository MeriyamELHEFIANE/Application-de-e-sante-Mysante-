// import 'package:flutter/material.dart';
// import 'package:patientapp/models/urgence_model.dart';
// // import 'package:forumapp/views/widgets/input_widget.dart';
// import 'package:get/get.dart';
// import 'package:patientapp/controllers/urgence_controller.dart';

// import '../widgets/input_widget.dart';
// import '../widgets/urgence_data.dart';

// class PostDetails extends StatefulWidget {
//   const PostDetails({super.key, required this.post});

//   final UrgenceModel post;

//   @override
//   State<PostDetails> createState() => _PostDetailsState();
// }

// class _PostDetailsState extends State<PostDetails> {
//   final TextEditingController _typeUrgenceController = TextEditingController();
//   final UrgenceController _postController = Get.put(UrgenceController());

//   @override
//   // void initState() {
//   //   WidgetsBinding.instance.addPostFrameCallback((_) {
//   //     _postController.getComments(widget.post.id);
//   //   });
//   //   super.initState();
//   // }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.black,
//         elevation: 0,
//         centerTitle: true,
//         title: Text(widget.post.user!.name!),
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Column(
//             children: [
//               PostData(
//                 post: widget.post,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               // Container(
//               //   width: double.infinity,
//               //   height: 300,
//               //   child: Obx(() {
//               //     return _postController.isLoading.value
//               //         ? Center(
//               //             child: CircularProgressIndicator(),
//               //           )
//               //         : ListView.builder(
//               //             itemCount: _postController.typeUrgences.value.length,
//               //             shrinkWrap: true,
//               //             itemBuilder: (context, index) {
//               //               return ListTile(
//               //                 title: Text(
//               //                   _postController
//               //                       .typeUrgences.value[index].user!.name!,
//               //                 ),
//               //                 subtitle: Text(
//               //                   _postController.typeUrgences.value[index].body!,
//               //                 ),
//               //               );
//               //             });
//               //   }),
//               // ),
//               InputWidget(
//                 obscureText: false,
//                 hintText: 'Write a comment...',
//                 controller: _typeUrgenceController,
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.black,
//                   elevation: 0,
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 50,
//                     vertical: 10,
//                   ),
//                 ),
//                 onPressed: () async {
//                   await _postController.createComment(
//                     widget.post.id,
//                     _typeUrgenceController.text.trim(),
//                   );
//                   _typeUrgenceController.clear();
//                 },
//                 child: const Text('Comment'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
