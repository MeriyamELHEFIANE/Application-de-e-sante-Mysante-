import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:patientapp/models/urgence_model.dart';
import 'package:patientapp/screens/util/cardiaque_card.dart';
import 'package:patientapp/screens/util/category_card.dart';
import 'package:patientapp/screens/util/doctor_card.dart';
import 'package:lottie/lottie.dart';
import '../controllers/medecin_controller.dart';
import '../controllers/urgence_controller.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final UrgenceController _postController = Get.put(UrgenceController());
  final PostController _medController = Get.put(PostController());
  final UrgenceModel post = UrgenceModel();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: SingleChildScrollView(
        child: Column(
          children: [
            //appBar
            SizedBox(height: 35),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  //name
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Text(
                      //   'Bienvenue,',
                      //   style: TextStyle(
                      //     fontWeight: FontWeight.bold,
                      //     fontSize: 18,
                      //   ),
                      // ),
                      SizedBox(height: 8),
                      Text(
                        'Bienvenue,',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  // profile picture
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.deepPurple[100],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.person),
                  ),
                ],
              ),
            ),
            SizedBox(height: 35),
            //card->how do you feel
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 69, 146, 108),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    //animation or cute picture
                    Container(
                      height: 140,
                      width: 120,
                      child: Lottie.network(
                        "https://assets4.lottiefiles.com/packages/lf20_T9jCikauOc.json",
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Comment vous sentez-vous?',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Choisissez votre urgence ou votre médecin ci-dessous dès maintenant',
                            style: TextStyle(
                              color: Colors.white54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    //how do you feel + get started button
                  ],
                ),
              ),
            ),
            SizedBox(height: 5),
            //search bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Liste des urgences',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    'voir tout',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 5),
            Container(
              height: 80,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Traumatique',
                          IconImagePath: 'lib/icons/traumatology.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CardiaqueCard(
                          categoryName: 'Cardiaque',
                          IconImagePath: 'lib/icons/crise-cardiaque.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Psycologie',
                          IconImagePath: 'lib/icons/psychology.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Gastro/uro',
                          IconImagePath: 'lib/icons/digestion.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Gynécologique',
                          IconImagePath: 'lib/icons/gynecology.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Neurologique',
                          IconImagePath: 'lib/icons/brain.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Respiratoire',
                          IconImagePath: 'lib/icons/lungs.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Corps étranger',
                          IconImagePath: 'lib/icons/psychology.png',
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    child: Column(
                      children: [
                        CategoryCard(
                          categoryName: 'Morsure/piqure',
                          IconImagePath: 'lib/icons/allergy.png',
                        ),
                      ],
                    ),
                  ),
                  CategoryCard(
                    categoryName: 'allergie',
                    IconImagePath: 'lib/icons/allergie.png',
                  ),
                ],
              ),
            ),
            SizedBox(height: 15),
            //doctor list
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Liste des médecins',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    'voir tout',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Obx(() {
                  return _medController.isLoading.value
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : GridView.builder(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                          ),
                          itemCount: _medController.med.value.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return DoctorCard(
                              post: _medController.med.value[index],
                            );
                          },
                        );
                  // : GridView.builder(
                  //     shrinkWrap: true,
                  //     gridDelegate:
                  //         SliverGridDelegateWithFixedCrossAxisCount(
                  //       crossAxisCount: 2,
                  //     ),
                  //     physics: const NeverScrollableScrollPhysics(),
                  //     itemCount: _medController.posts.value.length,
                  //     itemBuilder: (context, index) {
                  //       return Padding(
                  //         padding:
                  //             const EdgeInsets.symmetric(vertical: 8.0),
                  //         child: DoctorCard(
                  //           post: _medController.posts.value[index],
                  //         ),
                  //       );
                  //     },
                  //   );
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
