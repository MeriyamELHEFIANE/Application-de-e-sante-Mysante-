// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:patientapp/models/urgence_model.dart';
// import 'package:patientapp/screens/Morsures_piq%C3%BBre.dart';
// import 'package:patientapp/screens/Psychiatrique.dart';
// import 'package:patientapp/screens/allergique.dart';
// import 'package:patientapp/screens/cardiaque.dart';
// import 'package:patientapp/screens/exp.dart';
// import 'package:patientapp/screens/for_body.dart';
// import 'package:patientapp/screens/neurologique.dart';
// import 'package:patientapp/screens/respiratoire.dart';
// import 'package:patientapp/screens/traumatic.dart';
// import 'package:patientapp/screens/urgence.dart';
// import 'package:patientapp/screens/util/cardiaque_card.dart';
// import 'package:patientapp/screens/util/category_card.dart';
// import 'package:patientapp/screens/util/doctor_card.dart';
// import 'package:lottie/lottie.dart';
// import 'package:patientapp/screens/util/patient_card.dart';
// import 'package:patientapp/widgets/urgence_data.dart';

// import '../controllers/medecin_controller.dart';
// import '../controllers/patient_controller.dart';
// import '../controllers/urgence_controller.dart';
// import 'doctor_page.dart';

// class MyHomeDoctor extends StatefulWidget {
//   @override
//   _MyHomeDoctorState createState() => _MyHomeDoctorState();
// }

// class _MyHomeDoctorState extends State<MyHomeDoctor> {
//   final PatientController _medController = Get.put(PatientController());
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey[300],
//       body: SingleChildScrollView(
//         child: Column(children: [
//           //appBar
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 25.0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 //name
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       'Hello,',
//                       style: TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 18,
//                       ),
//                     ),
//                     SizedBox(height: 8),
//                     Text(
//                       'Meriyam Elhefiane,',
//                       style: TextStyle(
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ],
//                 ),
//                 //profile picture
//                 Container(
//                   padding: EdgeInsets.all(12),
//                   decoration: BoxDecoration(
//                     color: Colors.deepPurple[100],
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: Icon(Icons.person),
//                 ),
//               ],
//             ),
//           ),
//           SizedBox(height: 25),
//           //card->how do you feel
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 25.0),
//             child: Container(
//               padding: EdgeInsets.all(20),
//               decoration: BoxDecoration(
//                 color: Colors.green[200],
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: Row(
//                 children: [
//                   //animation or cute picture
//                   Container(
//                     height: 200,
//                     width: 200,
//                     child: Lottie.network(
//                       "https://assets2.lottiefiles.com/private_files/lf30_4FGi6N.json",
//                     ),
//                   ),
//                   SizedBox(
//                     width: 20,
//                   ),
//                   //how do you feel + get started button
//                   Expanded(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           'How do you feel?',
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             fontSize: 16,
//                           ),
//                         ),
//                         SizedBox(height: 12),
//                         Text(
//                           'Choose your emergency below right now',
//                           style: TextStyle(
//                             fontSize: 14,
//                           ),
//                         ),
//                         SizedBox(height: 12),
//                         Container(
//                           padding: EdgeInsets.all(12),
//                           decoration: BoxDecoration(
//                             color: Colors.deepPurple[300],
//                             borderRadius: BorderRadius.circular(12),
//                           ),
//                           child: Center(
//                             child: Text(
//                               'Emergency',
//                               style: TextStyle(color: Colors.white),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           SizedBox(height: 5),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 25.0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   'Patient list',
//                   style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     fontSize: 20,
//                   ),
//                 ),
//                 Text(
//                   'see all',
//                   style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     fontSize: 16,
//                     color: Colors.grey[500],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Column(
//             children: [
//               Obx(() {
//                 return _medController.isLoading.value
//                     ? const Center(
//                         child: CircularProgressIndicator(),
//                       )
//                     : GridView.builder(
//                         gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                           crossAxisCount: 2,
//                         ),
//                         itemCount: _medController.visits.value.length,
//                         shrinkWrap: true,
//                         physics: NeverScrollableScrollPhysics(),
//                         itemBuilder: (context, index) {
//                           return PatientCard(
//                             post: _medController.visits.value[index],
//                           );
//                         },
//                       );
//                 // : GridView.builder(
//                 //     shrinkWrap: true,
//                 //     gridDelegate:
//                 //         SliverGridDelegateWithFixedCrossAxisCount(
//                 //       crossAxisCount: 2,
//                 //     ),
//                 //     physics: const NeverScrollableScrollPhysics(),
//                 //     itemCount: _medController.posts.value.length,
//                 //     itemBuilder: (context, index) {
//                 //       return Padding(
//                 //         padding:
//                 //             const EdgeInsets.symmetric(vertical: 8.0),
//                 //         child: DoctorCard(
//                 //           post: _medController.posts.value[index],
//                 //         ),
//                 //       );
//                 //     },
//                 //   );
//               }),
//             ],
//           ),
//         ]
//             //search bar
//             ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';

// import 'package:get/get_navigation/get_navigation.dart';
import 'package:patientapp/screens/appointment_screen.dart';
import 'package:patientapp/screens/gridviewcode.dart';
import 'package:patientapp/screens/settings_screen.dart';
import 'package:patientapp/controllers/urgence_controller.dart';
import 'package:get/get.dart';
import 'package:patientapp/screens/util/patient_card.dart';

import '../controllers/patient_controller.dart';

// import 'package:patientapp/screens/visit_screen.dart';

class MyHomeDoctor extends StatefulWidget {
  @override
  State<MyHomeDoctor> createState() => _MyHomeDoctorState();
}

class _MyHomeDoctorState extends State<MyHomeDoctor> {
  final PatientController _medController = Get.put(PatientController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  //name
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bienvenue,',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Dr,',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  //profile picture
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.deepPurple[100],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.person),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 158, 195, 204),
                  // color: Color.fromARGB(255, 179, 153, 192),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    //animation or cute picture
                    Container(
                      height: 200,
                      width: 180,
                      child: Lottie.network(
                        "https://assets4.lottiefiles.com/private_files/lf30_4FGi6N.json",
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Voici les rendez-vous des patients qui ont besoin de vous',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            '"tu peux changer la vie de quelqu un"',
                            style: TextStyle(
                              color: Colors.white54,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    //how do you feel + get started button
                  ],
                ),
              ),
            ),
            SizedBox(height: 25),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Liste des rendez-vous',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    'Voir tout',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Column(
                children: [
                  Obx(() {
                    return _medController.isLoading.value
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : GridView.builder(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                            ),
                            itemCount: _medController.visits.value.length,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              return PatientCard(
                                post: _medController.visits.value[index],
                              );
                            },
                          );
                  }),
                ],
              ),
            )
            // Column(

            //   children: [
            //     Obx(() {
            //       return _medController.isLoading.value
            //           ? const Center(
            //               child: CircularProgressIndicator(),
            //             )
            //           : GridView.builder(
            //               gridDelegate:
            //                   SliverGridDelegateWithFixedCrossAxisCount(
            //                 crossAxisCount: 2,
            //               ),
            //               itemCount: _medController.visits.value.length,
            //               shrinkWrap: true,
            //               physics: NeverScrollableScrollPhysics(),
            //               itemBuilder: (context, index) {
            //                 return PatientCard(
            //                   post: _medController.visits.value[index],
            //                 );
            //               },
            //             );
            //     }),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}
