import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:patientapp/screens/login_screen.dart';
import 'package:patientapp/controllers/med_controller.dart';
import 'package:get/get.dart';
import 'package:patientapp/screens/signin_screen.dart';

class RegistreScreen extends StatefulWidget {
  @override
  State<RegistreScreen> createState() => _RegistreScreenState();
}

//medecin signup
class _RegistreScreenState extends State<RegistreScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _CNIController = TextEditingController();
  final TextEditingController _phone_numberController = TextEditingController();
  // final TextEditingController _SexController = TextEditingController();
  final TextEditingController _specialiteController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final MedController _medController = Get.put(MedController());

  bool passToggle = true;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: SingleChildScrollView(
        child: SafeArea(
            child: Column(
          children: [
            // SizedBox(height: 2),
            Padding(
              padding: EdgeInsets.all(5),
              child: Image.asset("assets/santee.png"),
            ),
            // SizedBox(height: 5),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Nom et prénom",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                controller: _nameController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "CNI",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.card_membership),
                ),
                controller: _CNIController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Numéro de téléphone",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
                controller: _phone_numberController,
              ),
            ),

            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "spécialité",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.date_range),
                ),
                controller: _specialiteController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Adresse e-mail",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                controller: _emailController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 15),
              child: TextField(
                obscureText: passToggle ? true : false,
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: "Mot de passe",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                  suffixIcon: InkWell(
                    onTap: () {
                      if (passToggle == true) {
                        passToggle = false;
                      } else {
                        passToggle = true;
                      }
                      setState(() {});
                    },
                    child: passToggle
                        ? Icon(CupertinoIcons.eye_slash_fill)
                        : Icon(CupertinoIcons.eye_fill),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: SizedBox(
                width: double.infinity,
                child: Material(
                  color: Color.fromARGB(255, 158, 195, 204),
                  // color: Color.fromARGB(255, 101, 214, 157),
                  borderRadius: BorderRadius.circular(10),
                  child: InkWell(
                    onTap: () async {
                      await _medController.register(
                        name: _nameController.text.trim(),
                        CNI: _CNIController.text.trim(),
                        phone_number: _phone_numberController.text.trim(),
                        specialite: _specialiteController.text.trim(),
                        email: _emailController.text.trim(),
                        password: _passwordController.text.trim(),
                      );
                    },
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 15,
                        horizontal: 40,
                      ),
                      child: Center(
                        child: Obx(() {
                          return _medController.isLoading.value
                              ? const Center(
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  "s'inscrire",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                );
                        }),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Vous avez déjà un compte ?",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black54,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SigninScreen(),
                        ));
                  },
                  child: Text(
                    "S'identifier",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      // color: Color.fromARGB(255, 101, 214, 157),
                      color: Color.fromARGB(255, 158, 195, 204),
                    ),
                  ),
                ),
              ],
            )
          ],
        )),
      ),
    );
  }
}
