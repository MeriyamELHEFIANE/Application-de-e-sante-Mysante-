import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:patientapp/screens/login_screen.dart';
import 'package:patientapp/controllers/authentication.dart';
import 'package:get/get.dart';

class SignUpScreen extends StatefulWidget {
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _CNIController = TextEditingController();
  final TextEditingController _phone_numberController = TextEditingController();
  // final TextEditingController _SexController = TextEditingController();
  final TextEditingController _date_of_birthController =
      TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthenticationController _authenticationController =
      Get.put(AuthenticationController());
  List<String> itemsList = ['', 'Mâle', 'Femelle'];
  String? Sex = '';

  bool passToggle = true;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: SingleChildScrollView(
        child: SafeArea(
            child: Column(
          children: [
            // SizedBox(height: 2),
            Padding(
              padding: EdgeInsets.all(5),
              child: Image.asset("assets/santee.png"),
            ),
            // SizedBox(height: 5),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Nom et prénom",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                controller: _nameController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "CNI",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.card_membership),
                ),
                controller: _CNIController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Numéro de téléphone",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
                controller: _phone_numberController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              // child: TextField(
              //   decoration: InputDecoration(
              //     labelText: "Sex",
              //     border: OutlineInputBorder(),
              //     prefixIcon: Icon(Icons.person),
              //   ),
              //   controller: _SexController,
              // ),
              child: SizedBox(
                width: 3000,
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    labelText: "Sexe",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person),
                  ),
                  value: Sex,
                  items: itemsList
                      .map((item) => DropdownMenuItem(
                          value: item,
                          child: Text(item, style: TextStyle(fontSize: 15))))
                      .toList(),
                  onChanged: (item) => setState(() => Sex = item),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "date de naissance",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.date_range),
                ),
                controller: _date_of_birthController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                decoration: InputDecoration(
                  labelText: "Adresse e-mail",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                controller: _emailController,
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              child: TextField(
                obscureText: passToggle ? true : false,
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: "Mot de passe",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                  suffixIcon: InkWell(
                    onTap: () {
                      if (passToggle == true) {
                        passToggle = false;
                      } else {
                        passToggle = true;
                      }
                      setState(() {});
                    },
                    child: passToggle
                        ? Icon(CupertinoIcons.eye_slash_fill)
                        : Icon(CupertinoIcons.eye_fill),
                  ),
                ),
              ),
            ),
            SizedBox(height: 5),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 2, horizontal: 25),
              // padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: Material(
                  color: Color.fromARGB(255, 101, 214, 157),
                  borderRadius: BorderRadius.circular(8),
                  child: InkWell(
                    onTap: () async {
                      await _authenticationController.register(
                        name: _nameController.text.trim(),
                        CNI: _CNIController.text.trim(),
                        phone_number: _phone_numberController.text.trim(),
                        Sex: Sex,
                        date_of_birth: _date_of_birthController.text.trim(),
                        email: _emailController.text.trim(),
                        password: _passwordController.text.trim(),
                      );
                    },
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 15,
                        horizontal: 40,
                      ),
                      child: Center(
                        child: Obx(() {
                          return _authenticationController.isLoading.value
                              ? const Center(
                                  child: CircularProgressIndicator(
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  "s'inscrire",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                );
                        }),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // SizedBox(height: 5),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Vous avez déjà un compte ?",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black54,
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LoginScreen(),
                        ));
                  },
                  child: Text(
                    "S'identifier",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 101, 214, 157),
                    ),
                  ),
                ),
              ],
            )
          ],
        )),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:patientapp/controllers/authentication.dart';
// import 'package:patientapp/views/login_page.dart';
// import 'package:get/get.dart';
// import './widgets/input_widget.dart';
// import 'package:google_fonts/google_fonts.dart';

// class RegisterPage extends StatefulWidget {
//   const RegisterPage({super.key});

//   @override
//   State<RegisterPage> createState() => _RegisterPageState();
// }

// class _RegisterPageState extends State<RegisterPage> {
//   final TextEditingController _nameController = TextEditingController();
//   final TextEditingController _CNIController = TextEditingController();
//   final TextEditingController _phone_numberController = TextEditingController();
//   final TextEditingController _SexController = TextEditingController();
//   final TextEditingController _date_of_birthController =
//       TextEditingController();
//   final TextEditingController _emailController = TextEditingController();
//   final TextEditingController _passwordController = TextEditingController();
//   final AuthenticationController _authenticationController =
//       Get.put(AuthenticationController());
//   @override
//   Widget build(BuildContext context) {
//     var size = MediaQuery.of(context).size.width;
//     return Scaffold(
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.symmetric(
//             horizontal: 20.0,
//           ),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Text(
//                 'Register Page',
//                 style: GoogleFonts.poppins(
//                   fontSize: size * 0.080,
//                 ),
//               ),
//               InputWidget(
//                 hintText: 'Name',
//                 obscureText: false,
//                 controller: _nameController,
//               ),
//               InputWidget(
//                 hintText: 'CNI',
//                 obscureText: false,
//                 controller: _CNIController,
//               ),
//               InputWidget(
//                 hintText: 'phone_number',
//                 obscureText: false,
//                 controller: _phone_numberController,
//               ),
//               InputWidget(
//                 hintText: 'Sex',
//                 obscureText: false,
//                 controller: _SexController,
//               ),
//               InputWidget(
//                 hintText: 'date_of_birth',
//                 obscureText: false,
//                 controller: _date_of_birthController,
//               ),
//               InputWidget(
//                 hintText: 'Email',
//                 obscureText: false,
//                 controller: _emailController,
//               ),
//               InputWidget(
//                 hintText: 'Password',
//                 obscureText: true,
//                 controller: _passwordController,
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.black,
//                   elevation: 0,
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 50,
//                     vertical: 15,
//                   ),
//                 ),
//                 onPressed: () async {
//                   await _authenticationController.register(
//                     name: _nameController.text.trim(),
//                     CNI: _CNIController.text.trim(),
//                     phone_number: _phone_numberController.text.trim(),
//                     Sex: _SexController.text.trim(),
//                     date_of_birth: _date_of_birthController.text.trim(),
//                     email: _emailController.text.trim(),
//                     password: _passwordController.text.trim(),
//                   );
//                 },
//                 child: Obx(() {
//                   return _authenticationController.isLoading.value
//                       ? const Center(
//                           child: CircularProgressIndicator(
//                             color: Colors.white,
//                           ),
//                         )
//                       : Text(
//                           'Register',
//                           style: GoogleFonts.poppins(
//                             fontSize: size * 0.040,
//                           ),
//                         );
//                 }),
//               ),
//               const SizedBox(
//                 height: 20,
//               ),
//               TextButton(
//                 onPressed: () {
//                   Get.to(() => const LoginPage());
//                 },
//                 child: Text(
//                   'Login',
//                   style: GoogleFonts.poppins(
//                     fontSize: size * 0.040,
//                     color: Colors.black,
//                   ),
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
