import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:lottie/lottie.dart';
import 'package:patientapp/screens/traumatic_card.dart';
import 'package:patientapp/screens/util/entrose_card.dart';
import 'home.dart';

class Traumatic extends StatefulWidget {
  const Traumatic({super.key});

  @override
  _TraumaticState createState() => _TraumaticState();
}

class _TraumaticState extends State<Traumatic> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 69, 146, 108),
        elevation: 0,
        // leading: Icon(Icons.arrow_back_ios_new),
        title: Text("Home"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 22),
            //card->how do you feel
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 69, 146, 108),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    //animation or cute picture
                    Container(
                      height: 200,
                      width: 200,
                      child: Lottie.network(
                        "https://assets5.lottiefiles.com/packages/lf20_HBUbm2mjqt.json",
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    //how do you feel + get started button
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Comment vous sentez-vous?',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 12),
                          // Text(
                          //   'Choisissez votre type d'
                          //   'urgence ci-dessous dès maintenant',
                          //   style: TextStyle(
                          //     fontSize: 14,
                          //   ),
                          // ),
                          SizedBox(height: 12),
                          // Container(
                          //   padding: EdgeInsets.all(12),
                          //   decoration: BoxDecoration(
                          //     color: Colors.deepPurple[300],
                          //     borderRadius: BorderRadius.circular(12),
                          //   ),
                          //   child: Center(
                          //     child: Text(
                          //       '',
                          //       style: TextStyle(color: Colors.white),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 50),
            //search bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Liste de sous-urgence',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                    ),
                  ),
                  // Text(
                  //   'see all',
                  //   style: TextStyle(
                  //     fontWeight: FontWeight.bold,
                  //     fontSize: 18,
                  //     color: Colors.grey[500],
                  //   ),
                  // ),
                ],
              ),
            ),
            SizedBox(height: 50),
            //horizontal listview
            Container(
              padding: EdgeInsets.only(top: 0),
              margin: EdgeInsets.symmetric(horizontal: 15),

              // onRefresh: () async {
              //   await _postController.getComments(widget.post);
              // },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListView.builder(
                      // scrollDirection: Axis.horizontal,
                      // gridDelegate:
                      //     SliverGridDelegateWithFixedCrossAxisCount(
                      //   crossAxisCount: 2,
                      // ),
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 1,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Column(
                          children: [
                            InkWell(
                              onTap: () {},
                              child: Column(
                                children: [
                                  TraumaticCard(
                                    ImagePath: 'lib/icons/os-casse.png',
                                    Name: 'Fracture',
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () {},
                              child: Column(
                                children: [
                                  EntroseCard(
                                    ImagePath: 'lib/icons/entorse.png',
                                    Name: 'Entorse',
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () {},
                              child: Column(
                                children: [
                                  TraumaticCard(
                                    ImagePath: 'lib/icons/blessure.png',
                                    Name: 'Coupure/plaie',
                                  ),
                                ],
                              ),
                            ),
                          ],
                        );
                      }),

                  // height: 70,
                  // Row(
                  //   children: [
                  //     InkWell(
                  //       onTap: () async {
                  //         await _postController.createComment(
                  //           widget.post.id,
                  //           symptoms,
                  //         );
                  //         // _commentController.clear();
                  //         _postController.getComments(widget.post.id);
                  //         ListView.builder(
                  //           shrinkWrap: true,
                  //           scrollDirection: Axis.horizontal,
                  //           itemCount: symptoms.length,
                  //           itemBuilder: (context, index) {
                  //             return Container(
                  //               margin: EdgeInsets.symmetric(
                  //                   vertical: 10, horizontal: 15),
                  //               padding: EdgeInsets.symmetric(horizontal: 25),
                  //               decoration: BoxDecoration(
                  //                 color: Color(0xFFF4F6FA),
                  //                 borderRadius: BorderRadius.circular(10),
                  //                 boxShadow: [
                  //                   BoxShadow(
                  //                     color: Colors.black12,
                  //                     blurRadius: 4,
                  //                     spreadRadius: 2,
                  //                   ),
                  //                 ],
                  //               ),
                  //               child: Center(
                  //                 child: Text(
                  //                   symptoms[index],
                  //                   style: TextStyle(
                  //                     fontSize: 16,
                  //                     fontWeight: FontWeight.w500,
                  //                     color: Colors.black54,
                  //                   ),
                  //                 ),
                  //               ),
                  //             );
                  //           },
                  //         );
                  //       },
                  //     )
                  //   ],
                  // ),

                  // InputWidget(
                  //   obscureText: false,
                  //   hintText: 'Write a comment...',
                  //   controller: _commentController,
                  // ),
                  // ElevatedButton(
                  //   style: ElevatedButton.styleFrom(
                  //     backgroundColor: Colors.black,
                  //     elevation: 0,
                  //     padding: const EdgeInsets.symmetric(
                  //       horizontal: 50,
                  //       vertical: 10,
                  //     ),
                  //   ),
                  //   onPressed: () async {
                  //     await _postController.createComment(
                  //       widget.post.id,
                  //       _commentController.text.trim(),
                  //     );
                  //     _commentController.clear();
                  //     _postController.getComments(widget.post.id);
                  //   },
                  //   child: const Text('Comment'),
                  // ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}






// import 'package:flutter/material.dart';
// import 'package:healthapp/models/post_model.dart';
// import 'package:healthapp/views/widgets/category_data.dart';
// import 'package:healthapp/views/widgets/input_widget.dart';
// import 'package:get/get.dart';
// import 'category_details.dart';
// import 'widgets/post_data.dart';
// import 'package:healthapp/controllers/post_controller.dart';

// class PostDetails extends StatefulWidget {
//   const PostDetails({super.key, required this.post});

//   final PostModel post;

//   @override
//   State<PostDetails> createState() => _PostDetailsState();
// }

// class _PostDetailsState extends State<PostDetails> {
//   final TextEditingController _commentController = TextEditingController();
//   final PostController _postController = Get.put(PostController());

//   @override
//   void initState() {
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       _postController.getComments(widget.post.id);
//     });
//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.black,
//         elevation: 0,
//         centerTitle: true,
//         title: Text(widget.post.user!.name!),
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Column(
//             children: [
//               PostData(
//                 post: widget.post,
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               Container(
//                 width: double.infinity,
//                 height: 300,
//                 child: Obx(() {
//                   return _postController.isLoading.value
//                       ? Center(
//                           child: CircularProgressIndicator(),
//                         )
//                       : ListView.builder(
//                           itemCount: _postController.comments.value.length,
//                           shrinkWrap: true,
//                           itemBuilder: (context, index) {
//                             return ListTile(
//                               title: Text(
//                                 _postController
//                                     .comments.value[index].user!.name!,
//                               ),
//                               subtitle: Text(
//                                 _postController.comments.value[index].body!,
//                               ),
//                               trailing: IconButton(
//                                 icon: Icon(Icons.favorite),
//                                 onPressed: () {
//                                   Get.to(
//                                     () => CategoryData(
//                                       post: widget.post,
//                                     ),
//                                   );
//                                 },
//                               ),
//                             );
//                           });
//                 }),
//               ),
//               InputWidget(
//                 obscureText: false,
//                 hintText: 'Write a comment...',
//                 controller: _commentController,
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.black,
//                   elevation: 0,
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 50,
//                     vertical: 10,
//                   ),
//                 ),
//                 onPressed: () async {
//                   await _postController.createComment(
//                     widget.post.id,
//                     _commentController.text.trim(),
//                   );
//                   _commentController.clear();
//                   _postController.getComments(widget.post.id);
//                 },
//                 child: const Text('Comment'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
