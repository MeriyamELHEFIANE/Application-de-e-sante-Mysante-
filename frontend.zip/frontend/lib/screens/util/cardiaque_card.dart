import 'package:flutter/material.dart';
import 'package:patientapp/controllers/urgence_controller.dart';
import 'package:get/get.dart';
import 'package:patientapp/screens/traumatic.dart';
import 'package:patientapp/widgets/urgence_data.dart';
import 'package:patientapp/widgets/urgence_detalis.dart';

import '../../models/category_model.dart';
import '../../models/urgence_model.dart';
import '../cardiaque.dart';
import '../urgence.dart';

class CardiaqueCard extends StatelessWidget {
  // const CategoryCard({super.key});
  final UrgenceController _urgenceController = Get.put(UrgenceController());
  final IconImagePath;
  final String categoryName;
  CardiaqueCard({
    required this.IconImagePath,
    required this.categoryName,
  });
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 25.0),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.deepPurple[300],
        ),
        child: Row(
          children: [
            // Image.asset(
            //   IconImagePath,
            //   height: 30,
            // ),
            // Text(categoryName),
            SizedBox(width: 10),
            // Text(categoryName),
            InkWell(
              onTap: () async {
                await _urgenceController.createPost(
                  type_of_emergency: categoryName,
                );
                _urgenceController.getAllUrgences();
                // ListView.builder(
                //   shrinkWrap: true,
                //   physics: const NeverScrollableScrollPhysics(),
                //   itemCount: _urgenceController.categories.value.length,
                //   itemBuilder: (context, index) {
                //     return Padding(
                //       padding: const EdgeInsets.symmetric(vertical: 8.0),
                //       child: PostData(
                //         post: _urgenceController.posts.value[index],
                //       ),
                //     );
                //   },
                // );
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Cardiaque(),
                  ),
                );
              },
              child: Column(children: [
                Text(
                  categoryName,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Image.asset(
                  IconImagePath,
                  height: 20,
                ),
              ]),
              // child: Container(
              //   child: Center(
              //     child: Text(categoryName),
              //   ),
              // ),
            )
          ],
        ),
      ),
    );
  }
}


// import 'package:flutter/material.dart';
// import 'package:patientapp/controllers/urgence_controller.dart';
// import 'package:get/get.dart';
// import 'package:patientapp/widgets/urgence_data.dart';
// import 'package:patientapp/widgets/urgence_detalis.dart';

// import '../../models/category_model.dart';
// import '../../models/urgence_model.dart';
// import '../cardiaque.dart';
// import '../urgence.dart';

// class CardiaqueCard extends StatelessWidget {
//   // const CategoryCard({super.key});
//   final UrgenceController _urgenceController = Get.put(UrgenceController());
//   final IconImagePath;
//   final String categoryName;
//   CardiaqueCard({
//     required this.IconImagePath,
//     required this.categoryName,
//   });
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.only(left: 25.0),
//       child: Container(
//         padding: EdgeInsets.all(20),
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(12),
//           color: Colors.deepPurple[300],
//         ),
//         child: Row(
//           children: [
//             // Image.asset(
//             //   IconImagePath,
//             //   height: 30,
//             // ),
//             // Text(categoryName),
//             SizedBox(width: 10),
//             // Text(categoryName),
//             InkWell(
//               onTap: () async {
//                 await _urgenceController.createPost(
//                   type_of_emergency: categoryName,
//                 );
//                 _urgenceController.getAllUrgences();
//                 // ListView.builder(
//                 //   shrinkWrap: true,
//                 //   physics: const NeverScrollableScrollPhysics(),
//                 //   itemCount: _urgenceController.categories.value.length,
//                 //   itemBuilder: (context, index) {
//                 //     return Padding(
//                 //       padding: const EdgeInsets.symmetric(vertical: 8.0),
//                 //       child: PostData(
//                 //         post: _urgenceController.posts.value[index],
//                 //       ),
//                 //     );
//                 //   },
//                 // );
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => PostDetails(),
//                   ),
//                 );
//               },
//               child: Column(children: [
//                 Text(
//                   categoryName,
//                   style: TextStyle(
//                     fontSize: 12,
//                     color: Colors.white,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 Image.asset(
//                   IconImagePath,
//                   height: 20,
//                 ),
//               ]),
//               // child: Container(
//               //   child: Center(
//               //     child: Text(categoryName),
//               //   ),
//               // ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
