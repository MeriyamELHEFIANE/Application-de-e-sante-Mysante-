import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../controllers/medecin_controller.dart';
import '../../models/med_model.dart';
import '../doctor_details.dart';

class DoctorCard extends StatefulWidget {
  const DoctorCard({
    super.key,
    required this.post,
  });

  final MedModel post;

  @override
  State<DoctorCard> createState() => _DoctorCardState();
}

class _DoctorCardState extends State<DoctorCard> {
  final PostController _medController = Get.put(PostController());
  bool likedPost = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Color.fromARGB(255, 69, 146, 108),
        // color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        // boxShadow: [
        //   BoxShadow(
        //     color: Colors.black12,
        //     blurRadius: 4,
        //     spreadRadius: 2,
        //   ),
        // ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          InkWell(
            onTap: () {
              Get.to(
                () => DoctorDetails(
                  post: widget.post,
                ),
              );
            },
            child: Column(children: [
              CircleAvatar(
                radius: 35,
                backgroundImage: AssetImage("assets/doctor_icn.png"),
                backgroundColor: Colors.white,
              ),
              Text(
                'Dr.',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                widget.post.name!,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
              // Text(
              //   widget.post.specialite!,
              //   style: TextStyle(
              //     fontSize: 18,
              //     fontWeight: FontWeight.w500,
              //     color: Colors.black54,
              //   ),
              // ),
              Text(
                widget.post.specialite!,
                style: TextStyle(
                  color: Colors.white54,
                ),
              ),
            ]),
          )
        ],
      ),
    );
  }
}
