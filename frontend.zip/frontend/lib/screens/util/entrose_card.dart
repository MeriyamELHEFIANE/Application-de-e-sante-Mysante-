import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:patientapp/screens/appointment_screen.dart';
import '../../controllers/urgence_controller.dart';
import '../../models/category_model.dart';
import 'entrose_details.dart';

class EntroseCard extends StatelessWidget {
  // const CategoryCard({super.key});
  final UrgenceController _urgenceController = Get.put(UrgenceController());
  final ImagePath;
  final String Name;
  EntroseCard({required this.ImagePath, required this.Name});
  // @override
  // void initState() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     _postController.getComments(post.id);
  //   });
  //   // super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(12),
      child: Container(
        padding: EdgeInsets.all(20),
        margin: EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.deepPurple[300],
          borderRadius: BorderRadius.circular(12),
          // boxShadow: [
          //   BoxShadow(
          //     color: Colors.black12,
          //     blurRadius: 4,
          //     spreadRadius: 2,
          //   ),
          // ],
        ),
        child: Row(
          children: [
            // SizedBox(width: 10),
            InkWell(
              onTap: () async {
                // Get.to(
                //   () => CategoryDetails(
                //     post: widget.post,
                //   ),
                // );
                await _urgenceController.createCategory(
                  Name,
                );
                _urgenceController.getCategory();

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EntroseDetails(),
                  ),
                );
              },
              child: Row(children: [
                Image.asset(
                  ImagePath,
                  height: 40,
                  width: 40,
                ),
                SizedBox(width: 100),
                Text(
                  Name,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ]),
              // child: Text(categoryName),
              // child: Column(children: [
              //   Text(
              //     symptoms[index],
              //   ),
              // ]),
            )
          ],
        ),
      ),
    );
  }
}
