import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../controllers/medecin_controller.dart';
import '../../controllers/patient_controller.dart';
import '../../models/med_model.dart';
import '../../models/visit_model.dart';
import '../doctor_details.dart';
import '../patient_details.dart';

class PatientCard extends StatefulWidget {
  const PatientCard({
    super.key,
    required this.post,
  });

  final VisitModel post;

  @override
  State<PatientCard> createState() => _PatientCardState();
}

class _PatientCardState extends State<PatientCard> {
  final PatientController _medController = Get.put(PatientController());
  bool likedPost = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(6),
      padding: EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        // color: Color.fromARGB(255, 158, 195, 204),
        // color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            spreadRadius: 2,
          ),
        ],
      ),
      // child: Row(
      //     children: [
      //       // SizedBox(width: 10),
      //       InkWell(
      //         onTap: () async {
      //           // Get.to(
      //           //   () => CategoryDetails(
      //           //     post: widget.post,
      //           //   ),
      //           // );
      //           await _urgenceController.createCategory(
      //             Name,
      //           );
      //           _urgenceController.getCategory();

      //           Navigator.push(
      //             context,
      //             MaterialPageRoute(
      //               builder: (context) => AppointmentScreen(),
      //             ),
      //           );
      //         },
      //         child: Row(children: [
      //           Image.asset(
      //             ImagePath,
      //             height: 40,
      //             width: 40,
      //           ),
      //           SizedBox(width: 100),
      //           Text(
      //             Name,
      //             style: TextStyle(
      //               fontWeight: FontWeight.bold,
      //               fontSize: 16,
      //             ),
      //           ),
      //         ]),
      //         // child: Text(categoryName),
      //         // child: Column(children: [
      //         //   Text(
      //         //     symptoms[index],
      //         //   ),
      //         // ]),
      //       )
      //     ],
      //   ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          InkWell(
            onTap: () {
              Get.to(
                PatientDetails(
                  post: widget.post,
                ),
              );
            },
            child: Column(children: [
              CircleAvatar(
                radius: 35,
                backgroundImage: AssetImage("assets/bed.png"),
                backgroundColor: Colors.white,
              ),
              Text(
                widget.post.user!.name!,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                widget.post.probleme!,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[500],
                ),
              ),
              // Text(
              //   widget.post.specialite!,
              //   style: TextStyle(
              //     fontSize: 18,
              //     fontWeight: FontWeight.w500,
              //     color: Colors.black54,
              //   ),
              // ),
              // Text(
              //   widget.post.user!.Sex!,
              //   style: TextStyle(
              //     color: Colors.black,
              //   ),
              // ),
              // Text(
              //   widget.post.user!.email!,
              //   style: TextStyle(
              //     fontSize: 18,
              //     fontWeight: FontWeight.w500,
              //     color: Colors.black54,
              //   ),
              // ),
              // Text(
              //   widget.post.user!.phone_number!,
              //   style: TextStyle(
              //     color: Colors.black45,
              //   ),
              // ),
            ]),
          )
        ],
      ),
    );
  }
}
