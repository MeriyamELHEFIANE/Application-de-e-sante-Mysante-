import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../controllers/medecin_controller.dart';
import '../../controllers/patient_controller.dart';
import '../../models/med_model.dart';
import '../../models/urgence_model.dart';

class VisitCard extends StatefulWidget {
  const VisitCard({
    super.key,
    required this.post,
  });

  final UrgenceModel post;

  @override
  State<VisitCard> createState() => _VisitCardState();
}

class _VisitCardState extends State<VisitCard> {
  // final PatientController _medController = Get.put(PatientController());
  bool likedPost = true;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(6),
      padding: EdgeInsets.symmetric(vertical: 15),
      decoration: BoxDecoration(
        color: Colors.white,
        // color: Color.fromARGB(255, 158, 195, 204),
        // color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          InkWell(
            // onTap: () {
            //   Get.to(
            //     PatientDetails(
            //       post: widget.post,
            //     ),
            //   );
            // },
            child: Column(children: [
              CircleAvatar(
                radius: 35,
                backgroundImage: AssetImage("assets/bed.png"),
                backgroundColor: Colors.white,
              ),
              Text(
                widget.post.user!.name!,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                widget.post.type_of_emergency!,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black,
                  fontWeight: FontWeight.w500,
                ),
              ),
              // Text(
              //   widget.post.user!.name!,
              //   style: TextStyle(
              //     fontSize: 18,
              //     color: Colors.black,
              //     fontWeight: FontWeight.w500,
              //   ),
              // ),
              // Text(
              //   widget.post.user!.Sex!,
              //   style: TextStyle(
              //     fontSize: 18,
              //     color: Colors.black,
              //     fontWeight: FontWeight.w500,
              //   ),
              // ),
              // Text(
              //   widget.post.!,
              //   style: TextStyle(
              //     color: Colors.black,
              //   ),
              // ),
            ]),
          )
        ],
      ),
    );
  }
}
