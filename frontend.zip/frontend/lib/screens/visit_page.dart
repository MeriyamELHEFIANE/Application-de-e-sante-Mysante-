import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';

// import 'package:get/get_navigation/get_navigation.dart';
import 'package:patientapp/screens/appointment_screen.dart';
import 'package:patientapp/screens/gridviewcode.dart';
import 'package:patientapp/screens/settings_screen.dart';
import 'package:patientapp/controllers/urgence_controller.dart';
import 'package:get/get.dart';
import 'package:patientapp/screens/util/patient_card.dart';
import 'package:patientapp/screens/util/visit_card.dart';

import '../controllers/patient_controller.dart';

// import 'package:patientapp/screens/visit_screen.dart';

class VisitPage extends StatefulWidget {
  @override
  State<VisitPage> createState() => _VisitPageState();
}

class _VisitPageState extends State<VisitPage> {
  final UrgenceController _medController = Get.put(UrgenceController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Padding(
            //   padding: const EdgeInsets.symmetric(horizontal: 25.0),
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       //name
            //       Column(
            //         crossAxisAlignment: CrossAxisAlignment.start,
            //         children: [
            //           Text(
            //             'Hello,',
            //             style: TextStyle(
            //               fontWeight: FontWeight.bold,
            //               fontSize: 18,
            //             ),
            //           ),
            //           SizedBox(height: 8),
            //           Text(
            //             'Doctor,',
            //             style: TextStyle(
            //               fontSize: 24,
            //               fontWeight: FontWeight.bold,
            //             ),
            //           ),
            //         ],
            //       ),
            //       //profile picture
            //       Container(
            //         padding: EdgeInsets.all(12),
            //         decoration: BoxDecoration(
            //           color: Colors.deepPurple[100],
            //           borderRadius: BorderRadius.circular(12),
            //         ),
            //         child: Icon(Icons.person),
            //       ),
            //     ],
            //   ),
            // ),
            SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 158, 195, 204),
                  // color: Color.fromARGB(255, 179, 153, 192),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    //animation or cute picture
                    // Container(
                    //   height: 200,
                    //   width: 180,
                    //   child: Lottie.network(
                    //     "https://assets4.lottiefiles.com/private_files/lf30_4FGi6N.json",
                    //   ),
                    // ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '  Liste des patients',
                            style: TextStyle(
                              fontSize: 28,
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    //how do you feel + get started button
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Column(
                children: [
                  Obx(() {
                    return _medController.isLoading.value
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : GridView.builder(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                            ),
                            itemCount: _medController.posts.value.length,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              return VisitCard(
                                post: _medController.posts.value[index],
                              );
                            },
                          );
                  }),
                ],
              ),
            )
            // Column(

            //   children: [
            //     Obx(() {
            //       return _medController.isLoading.value
            //           ? const Center(
            //               child: CircularProgressIndicator(),
            //             )
            //           : GridView.builder(
            //               gridDelegate:
            //                   SliverGridDelegateWithFixedCrossAxisCount(
            //                 crossAxisCount: 2,
            //               ),
            //               itemCount: _medController.visits.value.length,
            //               shrinkWrap: true,
            //               physics: NeverScrollableScrollPhysics(),
            //               itemBuilder: (context, index) {
            //                 return PatientCard(
            //                   post: _medController.visits.value[index],
            //                 );
            //               },
            //             );
            //     }),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}
