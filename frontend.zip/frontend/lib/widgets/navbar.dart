import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:patientapp/screens/home.dart';
import 'package:patientapp/screens/home_doctor.dart';

import '../screens/settings_screen.dart';
import '../screens/visit_page.dart';

class NavBar extends StatefulWidget {
  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _selectedIndex = 0;
  final _screens = [
    //home screen
    MyHomeDoctor(),
    //message Screen
    VisitPage(),
    //Schedule Screen
    // VisitScreen(),
    //Settings screen
    SettingsScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        height: 80,
        child: BottomNavigationBar(
          backgroundColor: Colors.grey[300],
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Color.fromARGB(255, 158, 195, 204),
          unselectedItemColor: Color.fromARGB(66, 121, 78, 78),
          selectedLabelStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_filled),
              label: "",
            ),
            // BottomNavigationBarItem(
            //   icon: Icon(CupertinoIcons.chat_bubble_text_fill),
            //   label: "Message",
            // ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: "",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: "",
            ),
          ],
        ),
      ),
    );
  }
}
