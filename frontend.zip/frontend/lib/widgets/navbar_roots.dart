import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:patientapp/screens/home.dart';

import '../screens/settings_screen.dart';

class NavBarRoots extends StatefulWidget {
  @override
  State<NavBarRoots> createState() => _NavBarState();
}

class _NavBarState extends State<NavBarRoots> {
  int _selectedIndex = 0;
  final _screens = [
    //home screen
    MyHomePage(),
    SettingsScreen(),
    //message Screen
    Container(),
    //Schedule Screen
    // VisitScreen(),
    //Settings screen
    // SettingsScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        height: 80,
        child: BottomNavigationBar(
          backgroundColor: Colors.grey[300],
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Colors.deepPurple[300],
          unselectedItemColor: Colors.black26,
          selectedLabelStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_filled),
              label: "",
            ),
            // BottomNavigationBarItem(
            //   icon: Icon(CupertinoIcons.chat_bubble_text_fill),
            //   label: "Message",
            // ),
            // BottomNavigationBarItem(
            //   // icon: Icon(Icons.calendar_month),
            //   label: "Schedule",
            // ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: "",
            ),
          ],
        ),
      ),
    );
  }
}
