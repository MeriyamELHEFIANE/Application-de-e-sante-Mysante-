// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:patientapp/models/category_model.dart';
// import 'package:patientapp/widgets/urgence_detalis.dart';

// import '../controllers/urgence_controller.dart';
// import '../models/urgence_model.dart';

// class PostData extends StatefulWidget {
//   const PostData({
//     super.key,
//     // required this.post,
//   });

//   // final UrgenceModel post;

//   @override
//   State<PostData> createState() => _PostDataState();
// }

// class _PostDataState extends State<PostData> {
//   final UrgenceController _urgenceController = Get.put(UrgenceController());
//   // bool likedPost = true;

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(10),
//       width: double.infinity,
//       decoration: BoxDecoration(
//         color: Colors.grey[200],
//         borderRadius: BorderRadius.circular(10),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Text(
//           //   widget.post.user!.email!,
//           //   style: GoogleFonts.poppins(),
//           // ),
//           const SizedBox(
//             height: 10,
//           ),
//           // Text(
//           //   widget.post.type_of_emergency!,
//           // ),
//           Row(
//             children: [
//               // IconButton(
//               //   onPressed: () async {
//               //     await _postController.likeAndDislike(widget.post.id);
//               //     _postController.getAllPosts();
//               //   },
//               //   icon: Icon(
//               //     Icons.thumb_up,
//               //     color: widget.post.liked! ? Colors.blue : Colors.black,
//               //   ),
//               // ),
//               IconButton(
//                 onPressed: () {
//                   Get.to(
//                     () => PostDetails(
//                       post: widget.post,
//                     ),
//                   );
//                 },
//                 icon: Icon(Icons.message),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }
