import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:patientapp/controllers/urgence_controller.dart';
import 'package:patientapp/models/category_model.dart';
import 'package:patientapp/widgets/urgence_data.dart';

import '../models/urgence_model.dart';
import 'input_widget.dart';

class PostDetails extends StatefulWidget {
  const PostDetails({super.key});

  // final UrgenceModel post;

  @override
  State<PostDetails> createState() => _PostDetailsState();
}

class _PostDetailsState extends State<PostDetails> {
  final TextEditingController _commentController = TextEditingController();
  final UrgenceController _urgenceController = Get.put(UrgenceController());

  final UrgenceModel post = UrgenceModel();
  // @override
  // void initState() {
  //   WidgetsBinding.instance.addPostFrameCallback((_) {
  //     _urgenceController.getCategory(post.id);
  //   });
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Colors.black,
      //   elevation: 0,
      //   centerTitle: true,
      //   title: Text(widget.post.user!.name!),
      // ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // PostData(
              //   post: widget.post,
              // ),
              const SizedBox(
                height: 10,
              ),
              Container(
                width: double.infinity,
                height: 300,
                child: Obx(() {
                  return _urgenceController.isLoading.value
                      ? Center(
                          child: CircularProgressIndicator(),
                        )
                      : ListView.builder(
                          itemCount: _urgenceController.categories.value.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return ListTile(
                              // title: Text(
                              //   _urgenceController
                              //       .categories.value[index].user!.name!,
                              // ),
                              subtitle: Text(
                                _urgenceController
                                    .categories.value[index].body!,
                              ),
                            );
                          });
                }),
              ),
              InputWidget(
                obscureText: false,
                hintText: 'Write a comment...',
                controller: _commentController,
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 50,
                    vertical: 10,
                  ),
                ),
                onPressed: () async {
                  await _urgenceController.createCategory(
                    _commentController.text.trim(),
                  );
                  _commentController.clear();
                  _urgenceController.getCategory();
                },
                child: const Text('Comment'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
